package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object baseUrl
     
    /**
     * <p></p>
     */
    public static Object url
     
    /**
     * <p></p>
     */
    public static Object accountno_pending
     
    /**
     * <p></p>
     */
    public static Object vin_pending
     
    /**
     * <p></p>
     */
    public static Object invalid_vin
     
    /**
     * <p></p>
     */
    public static Object invalid_acc
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            baseUrl = selectedVariables['baseUrl']
            url = selectedVariables['url']
            accountno_pending = selectedVariables['accountno_pending']
            vin_pending = selectedVariables['vin_pending']
            invalid_vin = selectedVariables['invalid_vin']
            invalid_acc = selectedVariables['invalid_acc']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
