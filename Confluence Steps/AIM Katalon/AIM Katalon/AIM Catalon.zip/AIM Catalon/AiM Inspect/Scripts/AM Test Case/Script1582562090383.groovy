import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://crm-qa.aiminspect.com/#!/inspection-request/search/basic')

WebUI.waitForPageLoad(5)

WebUI.getWindowTitle()

WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/img (1)'), 
    0)

WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/div_Username_container ng-scope layout-alig_5fd139'), 
    0)

WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/form_UsernamePasswordReset PasswordLog InIn_b7bd68 (1)'), 
    0)

WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/input_Username_username (1)'), 
    0)

WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/button_Log In (1)'), 
    0)

WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/button_Reset Password (1)'), 
    0)

WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/p_AiM AM v11900202002071819 QA  Copyright 2_b90d3a (1)'), 
    0)

WebUI.setText(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/input_Username_username (1)'), 
    'sample')

WebUI.setEncryptedText(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/input_Password_password'), 
    'e0cQP9FxRnrI2vaNykWqSQ==')

WebUI.click(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/button_Log In (1)'))

WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/img (1)'), 
    0)

WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/span_Dashboard'), 
    0)

WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/span_Request (1)'), 
    0)

WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/nav_DashboardRequestRequest ManagementSearc_0aeb54'), 
    0)

WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/a_Basic Search'), 
    0)

WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/a_Advanced Search'), 
    0)

WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/div_Active Records OnlySearch'), 
    0)

WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/div_VIN(s)_md-resize-handle'), 
    0)

WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/img (1)'), 
    0)

WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/p_AiM AM v11900202002071819 QA  Copyright 2_b90d3a (1)'), 
    0)

