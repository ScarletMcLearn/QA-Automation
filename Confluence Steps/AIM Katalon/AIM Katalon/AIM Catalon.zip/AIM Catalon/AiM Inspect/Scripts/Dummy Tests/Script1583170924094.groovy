import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys


def open_browser() {
	WebUI.openBrowser('')
	println('1')
}


def navigated_to_aim_assistant_manager_site() {
	WebUI.navigateToUrl('https://crm-qa.aiminspect.com/#!/inspection-request/search/basic')
	WebUI.waitForPageLoad(6)
	println('2')
}



def aim_assistant_manager_site_is_displayed() {
	
			WebUI.navigateToUrl('https://crm-uat.aiminspect.com/#!/inspection-request/search/basic')
			
			WebUI.waitForElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/img (2)'),
				6)
			
			WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/AIM Footer'),
				6)
			
			WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Password Field'),
				6)
			
			WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Username Textfield'),
				6)
			
			WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Reset Password Button'),
				6)
			
			WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Log In Button'),
				6)
			
			WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/AIM Footer'),
				6)
		}


def enter_correct_username_and_password() {

	WebUI.setText(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Username Textfield'),
			'sample')

	WebUI.setEncryptedText(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Password Field'),
			'e0cQP9FxRnrI2vaNykWqSQ==')
}


def click_login_button(){
	WebUI.click(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Log In Button'))

}


def click_on_dashboard()
{
	WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard Tab'))
	
	WebUI.waitForPageLoad(5)
}


def click_overdue_card() {
	WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Overdue Inspections Card'))
	
	WebUI.waitForPageLoad(5)
}



open_browser()
navigated_to_aim_assistant_manager_site()
aim_assistant_manager_site_is_displayed()
enter_correct_username_and_password()
click_login_button()
click_on_dashboard()

def subtext = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Overdue Inspections Card')).tokenize()[-1]

click_overdue_card()

println(subtext)

println(WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Results')).tokenize()[-1])

