import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://crm-qa.aiminspect.com/#!/inspection-request/search/basic')

WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/input_Username_username'))

WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/md-content_UsernamePasswordReset PasswordLo_aa700f'))

WebUI.setText(findTestObject('Object Repository/Page_AiM Assignment Manager/input_Username_username'), 
    'sample')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_AiM Assignment Manager/input_Password_password'), 
    'e0cQP9FxRnrI2vaNykWqSQ==')

WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/button_Log In'))

WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/span_Dashboard'))

WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/a_Dashboard'))

WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/span_Showing All States'))

WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/div_Alabama - AL'))

WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/md-backdrop_Dashboard_md-select-backdrop md_b6d90c'))

