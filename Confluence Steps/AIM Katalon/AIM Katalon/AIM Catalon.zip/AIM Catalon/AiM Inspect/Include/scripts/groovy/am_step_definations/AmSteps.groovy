package am_step_definations
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import java.awt.GraphicsConfiguration.DefaultBufferCapabilities
import java.awt.TexturePaintContext.Int

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.keyword.builtin.VerifyEqualKeyword
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

import cucumber.api.java.en.And
import cucumber.api.java.en.Given
import cucumber.api.java.en.Then
import cucumber.api.java.en.When

import org.openqa.selenium.Keys as Keys



class AmSteps {
	/**
	 * The step definitions below match with Katalon sample Gherkin steps
	 */
	//	@Given("I want to write a step with (.*)")
	//	def I_want_to_write_a_step_with_name(String name) {
	//		println name
	//	}
	//
	//	@When("I check for the (\\d+) in step")
	//	def I_check_for_the_value_in_step(int value) {
	//		println value
	//	}
	//
	//	@Then("I verify the (.*) in step")
	//	def I_verify_the_status_in_step(String status) {
	//		println status
	//	}
	//
	//


	//	@com.kms.katalon.core.annotation.TearDown
	//	def tear_down() {
	//		WebUI.closeBrowser()
	//	}

	@Given("Browser is opened")
	def open_browser() {
		WebUI.openBrowser('')
		println('1')
	}


	@Given("navigated to AIM Assistant Manager site // https://crm-qa.aiminspect.com/")
	def navigated_to_aim_assistant_manager_site() {
		WebUI.navigateToUrl('https://crm-qa.aiminspect.com/#!/inspection-request/search/basic')
		WebUI.waitForPageLoad(10)
		println('2')
	}


	@Given("AIM Assistant Manager site is displayed")
	def aim_assistant_manager_site_is_displayed() {
		//		//		WebUI.openBrowser('http://demoaut.katalon.com/')
		//		title = WebUI.getWindowTitle()
		//		title_correct = WebUI.verifyMatch(title, 'AiM Assignment Manager', true)
		//		logo_shown = WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/img'),
		//				0)
		//		assert title_correct && logo_shown && WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/img'),
		//		0) && WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/div_Username_container ng-scope layout-alig_5fd139'),
		//		0) && WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/form_UsernamePasswordReset PasswordLog InIn_b7bd68'),
		//		0) && WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/input_Username_username'),
		//		0) && WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/button_Log In'),
		//		0) && WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/button_Reset Password'),
		//		0) && WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/p_AiM AM v11900202002071819 QA  Copyright 2_b90d3a'),
		//		0) == true
		//
		//
		//		println('3')

		WebUI.navigateToUrl('https://crm-uat.aiminspect.com/#!/inspection-request/search/basic')

		WebUI.waitForElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/img (2)'),
				10)

		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/AIM Footer'),
				0)

		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Password Field'),
				0)

		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Username Textfield'),
				0)

		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Reset Password Button'),
				0)

		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Log In Button'),
				0)

		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/AIM Footer'),
				0)
	}


	@Given("correct user name and password is entered")
	def enter_correct_username_and_password() {
		//		WebUI.navigateToUrl('https://crm-qa.aiminspect.com/#!/inspection-request/search/basic')
		//		WebUI.waitForPageLoad(5)
		//		println('2')

		WebUI.setText(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Username Textfield'),
				'sample')

		WebUI.setEncryptedText(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Password Field'),
				'e0cQP9FxRnrI2vaNykWqSQ==')
	}


	@Given("login form is submitted")
	def click_login_button(){
		WebUI.click(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Log In Button'))

	}


	@Then("AIM Assistant Manager site logged in is displayed")
	def am_site_displayed() {
		//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/img'),
		//				0)
		//
		//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/span_Dashboard'),
		//				0)
		//
		//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/span_Request'),
		//				0)
		//
		//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/nav_DashboardRequestRequest ManagementSearc_0aeb54'),
		//				0)
		//
		//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/a_Basic Search'),
		//				0)
		//
		//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/a_Advanced Search'),
		//				0)
		//
		//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/div_Active Records OnlySearch'),
		//				0)
		//
		//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/div_VIN(s)_md-resize-handle'),
		//				0)
		//
		//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/img'),
		//				0)
		//
		//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/p_AiM AM v11900202002071819 QA  Copyright 2_b90d3a'),
		//				0)



		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/img (2)'),
				0)

		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/a_Dashboard'),
				0)

		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/span_Request'),
				0)

		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/input_Add organizations_input_0'),
				0)

		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/md-icon_Add organizations_person-icon ng-scope'),
				0)

		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/a_Advanced Search (1)'),
				0)

		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/a_Basic Search (1)'),
				0)

		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/input_Advanced Search_basic-search-input'),
				0)

		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/div_Active Records Only'),
				0)

		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/p_AiM AM v12300202003021654 QA  Copyright 2_625e3e'),
				0)

		WebUI.closeBrowser()
	}


	@When('click on Dashboard')
	def click_on_dashboard()
	{
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard Tab'))

		WebUI.waitForPageLoad(5)
	}


	@Then('Dashboard data is displayed')
	def dashboard_displayed() {
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/AIM Logo'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard Tab'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Request Tab'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Search Bar Icon'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Search Bar Tab'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Logout Button'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Showing All States'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Dispatch Card'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting CSR Card'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Quality Card'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Due Today Card'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Open Requests Card'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Overdue Inspections Card'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/AIM Footer'), 0)

		WebUI.closeBrowser()

	}




	@When('click on Overdue Inspection')
	def click_overdue_card() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Overdue Inspections Card'))

		WebUI.waitForPageLoad(5)
	}


	@Then('Overdue Inspection are displayed')
	def overdue_inspection_shown() {
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Results'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Overdue Inspections Label'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Export to Excel Button'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head VIN'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Type'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Status'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head State'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head SLA Date'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Request Date'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Name'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Customer'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Conf'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head City'), 0)

		WebUI.closeBrowser()
	}


	@When('click on Due today')
	def click_due_today() {

		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Due Today Card'))

		WebUI.waitForPageLoad(5)

	}


	@Then('Due today are displayed')
	def due_today_displayed() {


		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Due Today Icon'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Due Today Label'), 0)
		WebUI.closeBrowser()
	}



	@When('click on Awaiting CSR')
	def click_awaiting_csr() {

		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting CSR Card'))

		WebUI.waitForPageLoad(5)

	}



	@Then('Awaiting CSR are displayed')
	def awaiting_csr_displayed() {


		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting CSR Icon'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting CSR Label'), 0)
		WebUI.closeBrowser()
	}




	@When('click on Awaiting Dispatch')
	def click_awaiting_dispatch() {

		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Dispatch Card'))

		WebUI.waitForPageLoad(5)

	}



	@Then('Awaiting Dispatch are displayed')
	def awaiting_dispatch_displayed() {


		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Dispatch Icon'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Dispatch Label'), 0)
		WebUI.closeBrowser()
	}



	@When('click on Awaiting Quality')
	def click_quality_dispatch() {

		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Quality Card'))

		WebUI.waitForPageLoad(5)

	}



	@Then('Awaiting Quality are displayed')
	def awaiting_quality_displayed() {


		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Quality Icon'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Quality Label'), 0)
		WebUI.closeBrowser()
	}



	@When('click on Open Requests')
	def click_open_requests() {

		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Open Requests Card'))

		WebUI.waitForPageLoad(5)

	}



	@Then('Open Requests are displayed')
	def open_requests_displayed() {


		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Open Requests Icon'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Open Requests Label'), 0)
		WebUI.closeBrowser()
	}





	@When('click on Showing:All States')
	def click_showing_all_states() {

		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Showing All States 2'))

		WebUI.waitForPageLoad(5)

	}



	@Then('All States Dropdown menu is displayed')
	def all_states_displayed() {


		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Alabama State Option - AL'), 0)
		//			WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Open Requests Label'), 0)
		WebUI.closeBrowser()
	}



	@When('select an option from the menu')
	def select_an_option_from_dropdown_menu() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Alabama State Option - AL'))

		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Search Bar Icon'))
	}


	@Then('Dashboard is updated to show information of the option selected')
	def dashboard_updated() {

		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Showing AL'), 0)

		WebUI.closeBrowser()
	}


	def subtext = ''

	@And('see subtext on Overdue Inspections')
	def see_overdue_subtext() {

		subtext = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Overdue Inspections Card')).tokenize()[-1]

		//		println(subtext)

	}


	@Then('Overdue Inspections results count are same as the Overdue Inspections subtext')
	def overdue_count_result_count_same() {

		WebUI.verifyEqual(WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Results')).tokenize()[-1], subtext)

		WebUI.closeBrowser()
	}



	@And('see subtext on Due Today')
	def see_due_today_subtext() {

		subtext = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Due Today Card')).tokenize()[-1]

		//		println(subtext)

	}




	@Then('Due Today results count are same as the Due Today subtext')
	def due_today_count_result_count_same() {

		WebUI.verifyEqual(WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Results')).tokenize()[-1], subtext)

		WebUI.closeBrowser()
	}





	@And('see subtext on Awaiting CSR')
	def awaiting_csr_subtext() {

		subtext = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting CSR Card')).tokenize()[-1]

		//		println(subtext)

	}




	@Then('Awaiting CSR results count are same as the Awaiting CSR subtext')
	def awaiting_csr_count_result_count_same() {

		WebUI.verifyEqual(WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Results')).tokenize()[-1], subtext)

		WebUI.closeBrowser()
	}





	@And('see subtext on Awaiting Dispatch')
	def awaiting_dispatch_subtext() {

		subtext = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Dispatch Card')).tokenize()[-1]

		//		println(subtext)

	}




	@Then('Awaiting Dispatch results count are same as the Awaiting Dispatch subtext')
	def awaiting_dispatch_count_result_count_same() {

		WebUI.verifyEqual(WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Results')).tokenize()[-1], subtext)

		WebUI.closeBrowser()
	}





	@And('see subtext on Awaiting Quality')
	def awaiting_quality_subtext() {

		subtext = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Quality Card')).tokenize()[-1]

		//		println(subtext)

	}




	@Then('Awaiting Quality results count are same as the Awaiting Quality subtext')
	def awaiting_quality_count_result_count_same() {

		WebUI.verifyEqual(WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Results')).tokenize()[-1], subtext)

		WebUI.closeBrowser()
	}





	@And('see subtext on Open Requests')
	def open_requests_subtext() {

		subtext = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Open Requests Card')).tokenize()[-1]

		//		println(subtext)

	}




	@Then('Open Requests results count are same as the Open Requests subtext')
	def open_requests_count_result_count_same() {

		WebUI.verifyEqual(WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Results')).tokenize()[-1], subtext)

		WebUI.closeBrowser()
	}





	@When('select result from the results displayed')
	def click_first_result() {

		def first_result = findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/First Open Requests Result')
		subtext = WebUI.getText(first_result)

		//		println(subtext)

		WebUI.click(first_result)

		WebUI.delay(10)

	}



	@Then("selected result details are shown")
	def result_details_shown() {

		def curr_url = WebUI.getUrl().tokenize("/")


		WebUI.verifyEqual(subtext, curr_url[-1])
		//		println(subtext)
		//		println(curr_url)

		WebUI.closeBrowser()
	}


	@Then('Last updated date time stamp is shown')
	def last_updated_shown() {

		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Last updated tag'), 0)

		WebUI.closeBrowser()
	}


	@When('click on Export to Excel button')
	def click_export_to_excel() {

		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Export to Excel Button'))
	}



	@And('there are more than 25 Overdue Inspection')
	def more_than_25_overdue() {

		subtext = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Overdue Inspections Card')).tokenize()[-1]

		println(subtext)
		WebUI.verifyGreaterThanOrEqual(subtext, 25)

	}



	@Then("pages count tab is displayed")
	def pages_count_tab_is_displayed() {

		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Results Count'), 10)



	}


	@Then('close browser')
	def close_browser() {
		WebUI.closeBrowser()
	}



	def url = ''
	def url_2 = ''

	@Then('click on page 2')
	def click_page_2() {

		url = WebUI.getUrl()

		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Page 2'))


		println (url)

	}

	@Then('results updated')
	def results_updated() {
		url_2 = WebUI.getUrl()

		WebUI.verifyNotEqual(url_2, url)

		WebUI.closeBrowser()
	}


	@Then('Data is shown in Table')
	def data_table_is_shown() {

		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head City'), 10)
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Conf'), 10)
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Customer'), 10)
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Name'), 10)
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Request Date'), 10)
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head SLA Date'), 10)
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head State'), 10)
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Status'), 10)
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Type'), 10)
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head VIN'), 10)


		WebUI.closeBrowser()
	}




	@When('click on Request')
	def click_request_tab() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Request Tab'))
	}



	@When('input text in search bar which does not exist')
	def input_invalid_text() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Request Tab'))


		WebUI.setText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Search basic Search Input'), 'sdfsdf32423')


	}


	@And('click search')
	def click_search() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Search button'))


	}




	@Then("'No Results Found.' message is displayed")
	def no_results_found_message() {
		WebUI.verifyElementVisible(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/No Results Found')
				)

		WebUI.closeBrowser()
	}




	@When('input text in search bar which does exist')
	def input_valid_text() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Request Tab'))


		WebUI.setText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Search basic Search Input'), 'a')


		WebUI.delay(10)


	}





	@Then('search data is shown in Table')
	def search_data_table_is_shown() {

		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head City'), 10)
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Conf'), 10)
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Customer'), 10)
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Name'), 10)
		//						WebUI.verifyElementPresent(
		//							findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Request Date'), 10)
		//							WebUI.verifyElementPresent(
		//								findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head SLA Date'), 10)
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head State'), 10)
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Status'), 10)
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Type'), 10)
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head VIN'), 10)

		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Search Table Head Phone'), 10)


		WebUI.closeBrowser()
	}





	@Then('search bar on navigation menu is displayed')
	def search_bar_displayed() {


		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Search Bar Icon'), 10)

		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Search Bar'), 10)

		WebUI.closeBrowser()
	}





	@When ('click on State Dropdown menu')
	def click_state_dropdown_menu() {
		WebUI.click(
				//			findTestObject('Object Repository/Page_AiM Assignment Manager/Showing All States 2'))

				findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Select State 2')

				)
	}



	@And ('unselects all states')
	def unselects_all_states() {
		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Showing All States'))
	}



	@And ('clicks blank space on dashboard')
	def click_blank_space() {

		//		WebUI.delay(5)

		WebUI.click(
				//			findTestObject('Object Repository/Page_AiM Assignment Manager/Search Bar'))
				findTestObject('Object Repository/Page_AiM Assignment Manager/Search Bar Tab')
				)




	}



	@Then('Dashboard updated to no counts')
	def dashboard_shows_no_count() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Overdue Inspections Blank Count'), 10)

		WebUI.closeBrowser()
	}




	@And ('selects all states')
	def selects_all_states() {
		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Showing All States'))

		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Showing All States'))
	}




	def overdue_count = ''
	def new_overdue_count = ''
	@Then('Dashboard updated to all states counts')
	def all_states_count() {
		//			println(WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Overdue Inspections Label')))

		overdue_count = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Overdue Inspections Label'))

		//				println (overdue_count)

		assert overdue_count.length() > 0
	}



	@And ('selects Alabama')
	def select_alabama() {

		overdue_count = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Overdue Inspections Label'))

		WebUI.click(
				//				findTestObject('Object Repository/Page_AiM Assignment Manager/div_Alabama - AL')

				findTestObject('Object Repository/Page_AiM Assignment Manager/Alabama State Option - AL')
				)
	}


	@Then ('Dashboard updated to Alabama counts')
	def updated_alabama_counts() {

		new_overdue_count = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Overdue Inspections Label'))

		WebUI.verifyNotEqual(overdue_count, new_overdue_count)

		WebUI.closeBrowser()
	}



	@And ('selects Alaska')
	def select_alaska() {

		overdue_count = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Overdue Inspections Label'))

		WebUI.click(
				//				findTestObject('Object Repository/Page_AiM Assignment Manager/div_Alabama - AL')
				findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Alaska - AK Checkbox')

				)
	}



	@Then ('Dashboard updated to Alaska counts')
	def updated_alaska_counts() {

		new_overdue_count = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Overdue Inspections Label'))

		WebUI.verifyNotEqual(overdue_count, new_overdue_count)

		WebUI.closeBrowser()
	}




	@And ('selects Arizona')
	def select_arizona() {

		overdue_count = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Overdue Inspections Label'))

		WebUI.click(
				//				findTestObject('Object Repository/Page_AiM Assignment Manager/div_Alabama - AL')
				findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Arizona - AZ Checkbox')

				)
	}



	@Then ('Dashboard updated to Arizona counts')
	def updated_arizona_counts() {

		new_overdue_count = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Overdue Inspections Label'))

		WebUI.verifyNotEqual(overdue_count, new_overdue_count)

		WebUI.closeBrowser()
	}




	def arizona_count, alabama_count, alaska_count;

	@And('sees Arizona count')
	def see_arizona_count() {
		arizona_count = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Overdue Inspections Label'))
	}

	@And('sees Alabama count')
	def see_alabama_count() {
		alabama_count = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Overdue Inspections Label'))
	}


	@And('sees Alaska count')
	def see_alaska_count() {
		alaska_count = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Overdue Inspections Label'))
	}




	@Then ('Dashboard updated to  Arizona, Alaska and Alabama counts summed')
	def upsated_arizona_alaska_alabama_counts() {
		WebUI.verifyEqual(alabama_count+alaska_count+arizona_count, WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Overdue Inspections Label')))



		WebUI.closeBrowser()
	}



	def overdue_inspection_count = ''
	@And('see the result count')
	def see_overdue_inspection_count() {
		overdue_inspection_count = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Overdue Inspections Label'))
	}





	@And ('click the status of the first result')
	def click_first_status() {
		//	WebUI.click(	findTestObject(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Table Row 1')'Object Repository/Page_AiM Assignment Manager/Dashboard/Table Row 1')
		//	)

		url = WebUI.getUrl()

		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Row 1 Status')
				)

		WebUI.delay(5)
	}



	@Then('inspection request detail page is displayed')
	def inspection_request_detail_page_shown() {
		url_2 = WebUI.getUrl()

		WebUI.verifyNotEqual(url_2, url)

		//		WebUI.closeBrowser()
	}


	@And ('click current appointment detail option')
	def click_current_appointment_detail_option() {
		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Request Detail/Current Appointment Detail_Options')
				)
	}


	@And ('click cancel')
	def click_cancel() {
		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Request Detail/Cancel Inspection Request')
				)
	}
	//


	@And ('click Reason Dropdown Menu')
	def click_reason_dropdown_menu() {
		WebUI.click(findTestObject('Object findTestObjectRepository/Page_AiM Assignment Manager/Request Detail/Select_Cancel Reason Dropdown')
				) }

	//
	@And ('select Vehicle Purchased by Dealership reason')
	def select_vehicle_purchased_reason() {
		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Request Detail/Vehicle Purchased by Dealership')
				)
	}

	@And ('add a comment')
	def add_comment_on_cancel_reason() {

		WebUI.setText(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Request Detail/Cancel Comment')
				,
				'Comment for Cancelling')

	}
	//
	//
	@And ('click Confirm')
	def click_confirm() {
		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Request Detail/Confirm Cancel')
				)
	}
	//
	////
	//
	@And ('click the Close on Add Disposition')
	def click_close_add_disposition() {
		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Request Detail/Add Disposition_Window Close')
				)
	}
	//
	////

	//



	@When ('hover over Request tab')
	def hover_over_reuest_tab() {

		WebUI.mouseOver(
				findTestObject('Object Repository/Page_AiM Assignment Manager/Request Tab')
				)
	}


	@And ('click the Add organization')
	def click_add_organization() {

		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Add organizations link')
				)
	}


	@Then ('Add Organization page is shown')
	def add_organization_page_shown() {


		url = WebUI.getUrl()

		WebUI.verifyNotEqual('https://crm-uat.aiminspect.com/#!/organization/add', url)

		WebUI.closeBrowser()
	}



	@And ('User click Customer Dropdown menu')
	def click_customer_dropdown_menu() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Customer Dropdown Menu'))
	}


	@And ('select ALLY')
	def select_ally() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Customer Type ALLY'))
	}



	@And ('click Organization Type Dropdown menu')
	def click_org_type_dropdown_menu(){

		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Organization type Dropdown Menu 2'))
	}

	@And ('selects Dealer')
	def select_dealer() {
		//		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Organization Type Dealer 2'))

		WebUI.executeJavaScript('document.getElementById("select_option_40").click();', null)
	}

	@And ('clicks Organization name field')
	def click_org_name_field(){
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Organization name field'))
	}

	@And ('enters Organization name')
	def enter_org_name() {
		WebUI.setText(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Organization name field'),
				'sample')

	}



	@And ('selects US from Billing Address dropdown menu')
	def select_us_billing_address() {

		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Billing Address Dropdown Menu'))

		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Billing Address United States of America - US')
				)


	}


	@And ('clicks Street 1 field')
	def click_street_1_field() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Street 1'))
	}


	@And ('enters a valid Street')
	def enter_valid_street() {
		WebUI.setText(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Street 1'), '123, Gomes Street, Katalonia')
	}

	@And ('clicks City field')
	def click_city_field() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/City'))
	}

	@And ('enters a valid City')
	def enter_city() {
		WebUI.setText(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/City'), 'Lidian')
	}

	@And ('clicks State dropdown menu')
	def click_state_dropdown_menu_2() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/State Dropdown Menu'))
	}

	@And ('selects AL from state')
	def select_al_state() {
		//		WebUI.selectOptionByIndex(1)
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Alabama - AL 3'))
		//		WebUI.selectOptionByValue(findTestObject('Page_CuraAppointment/lst_Facility'), 'Hongkong CURA Healthcare Center', false)
	}

	@And ('clicks zip field')
	def click_zip_field() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Zip'))
	}

	@And ('enters a valid zip')
	def enters_valid_zip() {
		WebUI.setText(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Zip'), '35532')
	}

	@And ('checks Default Inspection Location as same as billing address')
	def click_same_as_billing_address() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Default inspection location Same As Billing Address'))
	}

	@And ('click Organization Code dropdown menu')
	def click_org_code_dropdown_menu() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Organization code type'))
	}

	@And ('select Auction Code from dropdown menu')
	def click_auction_code() {
				WebUI.click(
					findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Organization Code - Auction Code')
					)

//		WebUI.executeJavaScript('document.getElementById("select_option_41").click();', null)
	}

	@And ('click Organization code field')
	def click_org_code_field() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Organization Code'))
	}


	//	Give New Org Code
	@And ('enters valid Organization code')
	def enter_valid_org_code() {
		WebUI.setText(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Organization Code'), '1234')
	}

	@And ('click submit')
	def click_submit() {
		WebUI.sendKeys(
				findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Submit'), 'RETURN')
		//


		//		WebUI.executeJavaScript('document.getElementById("submit").click();', null)
	}

	//	Then organization created notification message displayed



	@And ('selects Auction')
	def select_auction() {
		//		WebUI.click(
		//			findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Organization Type Dealer 2')

		//		findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Organization type Auction')
		//		)
		//
		//		select_option_41

		WebUI.executeJavaScript('document.getElementById("select_option_41").click();', null)
	}




	@And ('select Chase')
	def select_chase() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Customer Type CHASE'))
	}



	@And ('selects AK from state')
	def select_alaska_2() {
		//		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Alaska - AK'))



		//		WebUiBuiltInKeywords.waitForElementVisible(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Alaska - AK 2'))

		//		WebUI.click(
		//			findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Alaska - AK 2')
		//			)


		WebUI.executeJavaScript('document.getElementById("select_option_46").click();', null)
	}



	@And ('selects MX from Billing Address dropdown menu')
	def select_mx_billing_address() {

		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Billing Address Dropdown Menu'))

		//		WebUI.click(
		//			findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Billing Address Mexico - MX')
		//						)



		WebUI.executeJavaScript('document.getElementById("select_option_43").click();', null)
	}



	@And ('selects AGU from state')
	def select_agu_state() {
		//		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Alaska - AK'))



		//		WebUiBuiltInKeywords.waitForElementVisible(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Alaska - AK 2'))

		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/State AGU')
				)


		//		 WebUI.executeJavaScript('document.getElementById("select_option_166").click();', null)
	}




	@And ('selects BCN from state')
	def select_bcn_state() {
		//		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Alaska - AK'))



		//		WebUiBuiltInKeywords.waitForElementVisible(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Alaska - AK 2'))

		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/State BCN')
				)


		//		 WebUI.executeJavaScript('document.getElementById("select_option_166").click();', null)
	}



	@And ('selects CA from Billing Address dropdown menu')
	def select_ca_billing_address() {

		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Billing Address Dropdown Menu'))

		//		WebUI.click(
		//			findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Billing Address Mexico - MX')
		//						)



		WebUI.executeJavaScript('document.getElementById("select_option_44").click();', null)
	}



	@And ('selects AB from state')
	def select_ab_state() {
		//		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Alaska - AK'))



		//		WebUiBuiltInKeywords.waitForElementVisible(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Alaska - AK 2'))

		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/State AB')

				)


		//		 WebUI.executeJavaScript('document.getElementById("select_option_166").click();', null)
	}




	@And ('selects BC from state')
	def select_bc_state() {
		//		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Alaska - AK'))



		//		WebUiBuiltInKeywords.waitForElementVisible(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Alaska - AK 2'))

		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/State BC')

				)


		//		 WebUI.executeJavaScript('document.getElementById("select_option_167").click();', null)
	}





	@And ('select VCI')
	def select_vci() {
		//		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Alaska - AK'))



		//		WebUiBuiltInKeywords.waitForElementVisible(findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Alaska - AK 2'))

		//		WebUI.click(
		//			findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Alaska - AK 2')
		//			)


		WebUI.executeJavaScript('document.getElementById("select_option_35").click();', null)
	}



	@And ('select VCI Dealer from dropdown menu')
	def select_vci_dealer_code() {


		WebUI.executeJavaScript('document.getElementById("select_option_165").click();', null)
	}

	//



	@And ('select MANHEIM')
	def select_manheim() {
		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Customer Type MANHEIM')
				)
	}


	@And ('select Auction Access Number from dropdown menu')
	def select_auction_access_number() {
		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Organization Code Auction access number')
				)
	}




	@And ('enter OVE Seller Group')
	def enter_ove_seller_group() {
		WebUI.sendKeys(
				findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/OVE Seller Group Field')
				, '1')
	}

	@And ('click Facilitated Auction code dropdown menu')
	def click_facilitated_auction_code_menu() {
		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Facilitated Auction Code')
				)
	}

	@And ('select 20187 from Facilitated Auction code dropdown menu')
	def select_20187() {
		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Facilated Auction Code 20187')
				)
	}

	@And ('click Physical Location Indicator dropdown menu')
	def click_physical_location_indicator_menu() {
		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Physical Location Indicator Dropdown Menu')

				)
	}

	@And ('select Dealer from Physical Location Indicator dropdown menu')
	def select_dealer_physical_location() {
		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Physical Location Indicator Dealer')
				)
	}


	@And ('select HYUNDAI')
	def select_hyundai() {
		WebUI.click(
				findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Customer Type HYUNDAI')
				)
	}
	
	
	@And ('select NISSAN')
	def select_nissan() {
		WebUI.click(
			findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Customer Type NISSAN')
			)
	}
	
	
	@And ('select Dealer Code from dropdown menu')
	def select_dealer_code() {
		WebUI.click(
			findTestObject('Object Repository/Page_AiM Assignment Manager/New Organization/Organization Code Dealer code')
			)
		
	}
	
	
	
}