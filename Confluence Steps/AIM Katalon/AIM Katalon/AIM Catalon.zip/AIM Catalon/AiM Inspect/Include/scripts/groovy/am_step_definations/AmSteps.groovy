package am_step_definations
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

import cucumber.api.java.en.And
import cucumber.api.java.en.Given
import cucumber.api.java.en.Then
import cucumber.api.java.en.When

import org.openqa.selenium.Keys as Keys



class AmSteps {
	/**
	 * The step definitions below match with Katalon sample Gherkin steps
	 */
	//	@Given("I want to write a step with (.*)")
	//	def I_want_to_write_a_step_with_name(String name) {
	//		println name
	//	}
	//
	//	@When("I check for the (\\d+) in step")
	//	def I_check_for_the_value_in_step(int value) {
	//		println value
	//	}
	//
	//	@Then("I verify the (.*) in step")
	//	def I_verify_the_status_in_step(String status) {
	//		println status
	//	}
	//
	//


//	@com.kms.katalon.core.annotation.TearDown
//	def tear_down() {
//		WebUI.closeBrowser()
//	}
	
	@Given("Browser is opened")
	def open_browser() {
		WebUI.openBrowser('')
		println('1')
	}


	@Given("navigated to AIM Assistant Manager site // https://crm-qa.aiminspect.com/")
	def navigated_to_aim_assistant_manager_site() {
		WebUI.navigateToUrl('https://crm-qa.aiminspect.com/#!/inspection-request/search/basic')
		WebUI.waitForPageLoad(10)
		println('2')
	}


	@Given("AIM Assistant Manager site is displayed")
	def aim_assistant_manager_site_is_displayed() {
//		//		WebUI.openBrowser('http://demoaut.katalon.com/')
//		title = WebUI.getWindowTitle()
//		title_correct = WebUI.verifyMatch(title, 'AiM Assignment Manager', true)
//		logo_shown = WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/img'),
//				0)
//		assert title_correct && logo_shown && WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/img'),
//		0) && WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/div_Username_container ng-scope layout-alig_5fd139'),
//		0) && WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/form_UsernamePasswordReset PasswordLog InIn_b7bd68'),
//		0) && WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/input_Username_username'),
//		0) && WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/button_Log In'),
//		0) && WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/button_Reset Password'),
//		0) && WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/p_AiM AM v11900202002071819 QA  Copyright 2_b90d3a'),
//		0) == true
//
//
//		println('3')
		
		WebUI.navigateToUrl('https://crm-uat.aiminspect.com/#!/inspection-request/search/basic')
		
		WebUI.waitForElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/img (2)'),
			10)
		
		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/AIM Footer'),
			0)
		
		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Password Field'),
			0)
		
		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Username Textfield'),
			0)
		
		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Reset Password Button'),
			0)
		
		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Log In Button'),
			0)
		
		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/AIM Footer'),
			0)
	}


	@Given("correct user name and password is entered")
	def enter_correct_username_and_password() {
		//		WebUI.navigateToUrl('https://crm-qa.aiminspect.com/#!/inspection-request/search/basic')
		//		WebUI.waitForPageLoad(5)
		//		println('2')

		WebUI.setText(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Username Textfield'),
				'sample')

		WebUI.setEncryptedText(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Password Field'),
				'e0cQP9FxRnrI2vaNykWqSQ==')
	}


	@Given("login form is submitted")
	def click_login_button(){
		WebUI.click(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/Log In Button'))

	}


	@Then("AIM Assistant Manager site logged in is displayed")
	def am_site_displayed() {
//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/img'),
//				0)
//
//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/span_Dashboard'),
//				0)
//
//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/span_Request'),
//				0)
//
//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/nav_DashboardRequestRequest ManagementSearc_0aeb54'),
//				0)
//
//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/a_Basic Search'),
//				0)
//
//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/a_Advanced Search'),
//				0)
//
//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/div_Active Records OnlySearch'),
//				0)
//
//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/div_VIN(s)_md-resize-handle'),
//				0)
//
//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/img'),
//				0)
//
//		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Page_AiM Assignment Manager/Page_AiM Assignment Manager/p_AiM AM v11900202002071819 QA  Copyright 2_b90d3a'),
//				0)


		
		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/img (2)'),
			0)
		
		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/a_Dashboard'),
			0)
		
		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/span_Request'),
			0)
		
		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/input_Add organizations_input_0'),
			0)
		
		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/md-icon_Add organizations_person-icon ng-scope'),
			0)
		
		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/a_Advanced Search (1)'),
			0)
		
		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/a_Basic Search (1)'),
			0)
		
		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/input_Advanced Search_basic-search-input'),
			0)
		
		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/div_Active Records Only'),
			0)
		
		WebUI.verifyElementPresent(findTestObject('Page_AiM Assignment Manager/Page_AiM Assignment Manager/p_AiM AM v12300202003021654 QA  Copyright 2_625e3e'),
			0)
		
		WebUI.closeBrowser()
	}
	
	
	@When('click on Dashboard')
	def click_on_dashboard()
	{
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard Tab'))
		
		WebUI.waitForPageLoad(5)
	}
	
	
	@Then('Dashboard data is displayed')
	def dashboard_displayed() {
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/AIM Logo'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard Tab'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Request Tab'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Search Bar Icon'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Search Bar Tab'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Logout Button'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Showing All States'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Dispatch Card'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting CSR Card'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Quality Card'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Due Today Card'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Open Requests Card'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Overdue Inspections Card'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/AIM Footer'), 0)
		
		WebUI.closeBrowser()
		
	}
	
	
	
	
	@When('click on Overdue Inspection')
	def click_overdue_card() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Overdue Inspections Card'))
		
		WebUI.waitForPageLoad(5)
	}
	
	
	@Then('Overdue Inspection are displayed')
	def overdue_inspection_shown() {
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Results'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Overdue Inspections Label'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Export to Excel Button'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head VIN'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Type'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Status'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head State'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head SLA Date'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Request Date'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Name'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Customer'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head Conf'), 0)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Table Head City'), 0)
		
		WebUI.closeBrowser()
	}
	
	
	@When('click on Due today')
	def click_due_today() {
		
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Due Today Card'))
	
		WebUI.waitForPageLoad(5)
		
		}
	
	
	@Then('Due today are displayed')
	def due_today_displayed() {
		
		
			WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Due Today Icon'), 0)
			WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Due Today Label'), 0)
			WebUI.closeBrowser()
	}
	
	
	
	@When('click on Awaiting CSR')
	def click_awaiting_csr() {
		
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting CSR Card'))
	
		WebUI.waitForPageLoad(5)
		
		}
	
	
	
	@Then('Awaiting CSR are displayed')
	def awaiting_csr_displayed() {
		
		
			WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting CSR Icon'), 0)
			WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting CSR Label'), 0)
			WebUI.closeBrowser()
	}
	
	
	
	
	@When('click on Awaiting Dispatch')
	def click_awaiting_dispatch() {
		
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Dispatch Card'))
	
		WebUI.waitForPageLoad(5)
		
		}
	
	
	
	@Then('Awaiting Dispatch are displayed')
	def awaiting_dispatch_displayed() {
		
		
			WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Dispatch Icon'), 0)
			WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Dispatch Label'), 0)
			WebUI.closeBrowser()
	}
	
	
	
	@When('click on Awaiting Quality')
	def click_quality_dispatch() {
		
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Quality Card'))
	
		WebUI.waitForPageLoad(5)
		
		}
	
	
	
	@Then('Awaiting Quality are displayed')
	def awaiting_quality_displayed() {
		
		
			WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Quality Icon'), 0)
			WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Quality Label'), 0)
			WebUI.closeBrowser()
	}
	
	
	
	@When('click on Open Requests')
	def click_open_requests() {
		
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Open Requests Card'))
	
		WebUI.waitForPageLoad(5)
		
		}
	
	
	
	@Then('Open Requests are displayed')
	def open_requests_displayed() {
		
		
			WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Open Requests Icon'), 0)
			WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Open Requests Label'), 0)
			WebUI.closeBrowser()
	}
	
	
	
	
	
	@When('click on Showing:All States')
	def click_showing_all_states() {
		
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Showing All States 2'))
	
		WebUI.waitForPageLoad(5)
		
		}
	
	
	
	@Then('All States Dropdown menu is displayed')
	def all_states_displayed() {
		
		
			WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Alabama State Option - AL'), 0)
//			WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Open Requests Label'), 0)
			WebUI.closeBrowser()
	}
	
	
	
	@When('select an option from the menu')
	def select_an_option_from_dropdown_menu() {
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Alabama State Option - AL'))
		
		WebUI.click(findTestObject('Object Repository/Page_AiM Assignment Manager/Search Bar Icon'))
	}
	
	
	@Then('Dashboard is updated to show information of the option selected')
	def dashboard_updated() {
		
		WebUI.verifyElementPresent(findTestObject('Object Repository/Page_AiM Assignment Manager/Showing AL'), 0)
		
		WebUI.closeBrowser()
	}
	
	
	def subtext = ''
	
	@And('see subtext on Overdue Inspections')
	def see_overdue_subtext() {
		
		subtext = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Overdue Inspections Card')).tokenize()[-1]
		
//		println(subtext)
		
			}
	
	
	@Then('Overdue Inspections results count are same as the Overdue Inspections subtext')
	def overdue_count_result_count_same() {
		
		WebUI.verifyEqual(WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Results')).tokenize()[-1], subtext)
	
		WebUI.closeBrowser()
		}
	
	
	
	@And('see subtext on Due Today')
	def see_due_today_subtext() {
		
		subtext = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Due Today Card')).tokenize()[-1]
		
//		println(subtext)
		
			}
	
	
	
	
	@Then('Due Today results count are same as the Due Today subtext')
	def due_today_count_result_count_same() {
		
		WebUI.verifyEqual(WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Results')).tokenize()[-1], subtext)
	
		WebUI.closeBrowser()
		}
	
	
	
	
	
	@And('see subtext on Awaiting CSR')
	def awaiting_csr_subtext() {
		
		subtext = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting CSR Card')).tokenize()[-1]
		
//		println(subtext)
		
			}
	
	
	
	
	@Then('Awaiting CSR results count are same as the Awaiting CSR subtext')
	def awaiting_csr_count_result_count_same() {
		
		WebUI.verifyEqual(WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Results')).tokenize()[-1], subtext)
	
		WebUI.closeBrowser()
		}
	
	
	
	
	
	@And('see subtext on Awaiting Dispatch')
	def awaiting_dispatch_subtext() {
		
		subtext = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Dispatch Card')).tokenize()[-1]
		
//		println(subtext)
		
			}
	
	
	
	
	@Then('Awaiting Dispatch results count are same as the Awaiting Dispatch subtext')
	def awaiting_dispatch_count_result_count_same() {
		
		WebUI.verifyEqual(WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Results')).tokenize()[-1], subtext)
	
		WebUI.closeBrowser()
		}
	
	
	
	
	
	@And('see subtext on Awaiting Quality')
	def awaiting_quality_subtext() {
		
		subtext = WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Awaiting Quality Card')).tokenize()[-1]
		
//		println(subtext)
		
			}
	
	
	
	
	@Then('Awaiting Quality results count are same as the Awaiting Quality subtext')
	def awaiting_quality_count_result_count_same() {
		
		WebUI.verifyEqual(WebUI.getText(findTestObject('Object Repository/Page_AiM Assignment Manager/Dashboard/Results')).tokenize()[-1], subtext)
	
		WebUI.closeBrowser()
		}
}