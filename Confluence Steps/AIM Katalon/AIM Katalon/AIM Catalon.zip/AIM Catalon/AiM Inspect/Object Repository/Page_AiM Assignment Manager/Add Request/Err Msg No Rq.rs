<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Err Msg No Rq</name>
   <tag></tag>
   <elementGuidId>86b64797-d4d8-4453-b738-241aab1ec5e8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;content-container&quot;]/div/div/h1/span</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@ng-message = 'required']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-message</name>
      <type>Main</type>
      <value>required</value>
   </webElementProperties>
</WebElementEntity>
