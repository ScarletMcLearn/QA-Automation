<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DD Rq Typ Dealer</name>
   <tag></tag>
   <elementGuidId>485dc7bf-5184-4b35-b20d-72b192086315</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>/html/body/div[4]/md-select-menu/md-content/md-option[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@tabindex = '0']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
   </webElementProperties>
</WebElementEntity>
