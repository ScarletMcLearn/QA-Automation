<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>US States</name>
   <tag></tag>
   <elementGuidId>fee7b14e-69a3-4f3b-b44d-c662582c8514</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//md-select[@id='select_244']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[(contains(text(), 'Select state
								
									Alabama - AL
								
									Alaska - AK
								
									Arizona - AZ
								
									Arkansas - AR
								
									California - CA
								
									Colorado - CO
								
									Connecticut - CT
								
									Delaware - DE
								
									District of Columbia - DC
								
									Florida - FL
								
									Georgia - GA
								
									Hawaii - HI
								
									Idaho - ID
								
									Illinois - IL
								
									Indiana - IN
								
									Iowa - IA
								
									Kansas - KS
								
									Kentucky - KY
								
									Louisiana - LA
								
									Maine - ME
								
									Maryland - MD
								
									Massachusetts - MA
								
									Michigan - MI
								
									Minnesota - MN
								
									Mississippi - MS
								
									Missouri - MO
								
									Montana - MT
								
									Nebraska - NE
								
									Nevada - NV
								
									New Hampshire - NH
								
									New Jersey - NJ
								
									New Mexico - NM
								
									New York - NY
								
									North Carolina - NC
								
									North Dakota - ND
								
									Ohio - OH
								
									Oklahoma - OK
								
									Oregon - OR
								
									Pennsylvania - PA
								
									Puerto Rico - PR
								
									Rhode Island - RI
								
									South Carolina - SC
								
									South Dakota - SD
								
									Tennessee - TN
								
									Texas - TX
								
									Utah - UT
								
									Vermont - VT
								
									Virgin Islands, U.S. - VI
								
									Virginia - VA
								
									Washington - WA
								
									West Virginia - WV
								
									Wisconsin - WI
								
									Wyoming - WY
								
							') or contains(., 'Select state
								
									Alabama - AL
								
									Alaska - AK
								
									Arizona - AZ
								
									Arkansas - AR
								
									California - CA
								
									Colorado - CO
								
									Connecticut - CT
								
									Delaware - DE
								
									District of Columbia - DC
								
									Florida - FL
								
									Georgia - GA
								
									Hawaii - HI
								
									Idaho - ID
								
									Illinois - IL
								
									Indiana - IN
								
									Iowa - IA
								
									Kansas - KS
								
									Kentucky - KY
								
									Louisiana - LA
								
									Maine - ME
								
									Maryland - MD
								
									Massachusetts - MA
								
									Michigan - MI
								
									Minnesota - MN
								
									Mississippi - MS
								
									Missouri - MO
								
									Montana - MT
								
									Nebraska - NE
								
									Nevada - NV
								
									New Hampshire - NH
								
									New Jersey - NJ
								
									New Mexico - NM
								
									New York - NY
								
									North Carolina - NC
								
									North Dakota - ND
								
									Ohio - OH
								
									Oklahoma - OK
								
									Oregon - OR
								
									Pennsylvania - PA
								
									Puerto Rico - PR
								
									Rhode Island - RI
								
									South Carolina - SC
								
									South Dakota - SD
								
									Tennessee - TN
								
									Texas - TX
								
									Utah - UT
								
									Vermont - VT
								
									Virgin Islands, U.S. - VI
								
									Virginia - VA
								
									Washington - WA
								
									West Virginia - WV
								
									Wisconsin - WI
								
									Wyoming - WY
								
							'))]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>md-select</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>placeholder</name>
      <type>Main</type>
      <value>Select state</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-model</name>
      <type>Main</type>
      <value>parameters.state</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-disabled</name>
      <type>Main</type>
      <value>!parameters.country</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-pristine ng-untouched ng-valid flex ng-empty</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Select state</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>listbox</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-expanded</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-multiselectable</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>select_244</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-disabled</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-invalid</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Select state
								
									Alabama - AL
								
									Alaska - AK
								
									Arizona - AZ
								
									Arkansas - AR
								
									California - CA
								
									Colorado - CO
								
									Connecticut - CT
								
									Delaware - DE
								
									District of Columbia - DC
								
									Florida - FL
								
									Georgia - GA
								
									Hawaii - HI
								
									Idaho - ID
								
									Illinois - IL
								
									Indiana - IN
								
									Iowa - IA
								
									Kansas - KS
								
									Kentucky - KY
								
									Louisiana - LA
								
									Maine - ME
								
									Maryland - MD
								
									Massachusetts - MA
								
									Michigan - MI
								
									Minnesota - MN
								
									Mississippi - MS
								
									Missouri - MO
								
									Montana - MT
								
									Nebraska - NE
								
									Nevada - NV
								
									New Hampshire - NH
								
									New Jersey - NJ
								
									New Mexico - NM
								
									New York - NY
								
									North Carolina - NC
								
									North Dakota - ND
								
									Ohio - OH
								
									Oklahoma - OK
								
									Oregon - OR
								
									Pennsylvania - PA
								
									Puerto Rico - PR
								
									Rhode Island - RI
								
									South Carolina - SC
								
									South Dakota - SD
								
									Tennessee - TN
								
									Texas - TX
								
									Utah - UT
								
									Vermont - VT
								
									Virgin Islands, U.S. - VI
								
									Virginia - VA
								
									Washington - WA
								
									West Virginia - WV
								
									Wisconsin - WI
								
									Wyoming - WY
								
							</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;select_244&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//md-select[@id='select_244']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='crm-organization-search-form']/div/div[3]/div[2]/md-input-container/md-select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='State'])[1]/following::md-select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='United States of America - US'])[1]/following::md-select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div[2]/md-input-container/md-select</value>
   </webElementXpaths>
</WebElementEntity>
