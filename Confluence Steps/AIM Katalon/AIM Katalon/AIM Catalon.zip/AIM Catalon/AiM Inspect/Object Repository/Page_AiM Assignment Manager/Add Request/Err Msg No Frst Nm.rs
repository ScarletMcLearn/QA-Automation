<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Err Msg No Frst Nm</name>
   <tag></tag>
   <elementGuidId>177458d3-9cba-48ff-a3ff-d6f860ebdafd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;content-container&quot;]/div/div/form/section/div/div[2]/div/div[1]/md-input-container[1]/div[2]/div</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@ng-message = 'required']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-message</name>
      <type>Main</type>
      <value>required</value>
   </webElementProperties>
</WebElementEntity>
