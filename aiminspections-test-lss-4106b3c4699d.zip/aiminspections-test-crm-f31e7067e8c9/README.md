##Test AiM Inspect##

###Cucumber framework for testing the AiM CRM web app. Uses Webdriverio.

####Configuration####

Install Node.js

####Installation####

You should be able to just run:

npm install

Otherwise install packages manually:

npm install -g cucumber webdriverio

npm install wdio-cucumber-framework wdio-junit-reporter wdio-spec-reporter wdio-phantomjs-service "wdio-firefox-profile-service deepmerge chai chai-as-promised child-process fs request

####How to run tests####

wdio