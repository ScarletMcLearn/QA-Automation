'use strict';

let browser = global.browser;

module.exports = function clickSubmit () {
	browser.click('button#submit');
};

