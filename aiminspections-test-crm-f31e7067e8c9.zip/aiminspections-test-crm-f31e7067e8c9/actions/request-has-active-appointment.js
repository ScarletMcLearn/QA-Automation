'use strict';

module.exports = function (hasActiveAppointment, cb) {
	return cb();
};

