'use strict';

module.exports = action => require('./' + action);

