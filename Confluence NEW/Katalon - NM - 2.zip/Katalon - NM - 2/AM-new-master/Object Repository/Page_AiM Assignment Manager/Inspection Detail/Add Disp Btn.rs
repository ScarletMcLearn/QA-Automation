<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Add Disp Btn</name>
   <tag></tag>
   <elementGuidId>d513458b-8ce7-47df-aa1b-9f7a754b1640</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
