<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Cust Type</name>
   <tag></tag>
   <elementGuidId>729b272a-18d7-4117-9a5b-cf16878a5bbc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@placeholder, 'Select disposition type')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>placeholder</name>
      <type>Main</type>
      <value>Select disposition type</value>
   </webElementProperties>
</WebElementEntity>
