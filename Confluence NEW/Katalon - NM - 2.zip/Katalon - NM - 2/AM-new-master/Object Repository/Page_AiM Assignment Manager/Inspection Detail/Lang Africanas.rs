<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Lang Africanas</name>
   <tag></tag>
   <elementGuidId>bde781b9-0cd4-4e2c-9b61-2acd8efd3143</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@value, 'af')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>value</name>
      <type>Main</type>
      <value>af</value>
   </webElementProperties>
</WebElementEntity>
