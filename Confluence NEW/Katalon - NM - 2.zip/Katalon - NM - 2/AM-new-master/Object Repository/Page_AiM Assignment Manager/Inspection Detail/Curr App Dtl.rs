<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Curr App Dtl</name>
   <tag></tag>
   <elementGuidId>e81acca2-aee9-4cf1-a028-63101fd7e395</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@ui-view = 'appointment']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ui-view</name>
      <type>Main</type>
      <value>appointment</value>
   </webElementProperties>
</WebElementEntity>
