<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Arabic</name>
   <tag></tag>
   <elementGuidId>f051cd73-509c-4d40-a859-de89d7220a13</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@value, 'ar')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>value</name>
      <type>Main</type>
      <value>ar</value>
   </webElementProperties>
</WebElementEntity>
