<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>State 2</name>
   <tag></tag>
   <elementGuidId>7178db98-8f1b-4259-8c4f-63f7ced14438</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@name = 'state']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;select_value_label_73&quot;]/span[1]/text()</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>state</value>
   </webElementProperties>
</WebElementEntity>
