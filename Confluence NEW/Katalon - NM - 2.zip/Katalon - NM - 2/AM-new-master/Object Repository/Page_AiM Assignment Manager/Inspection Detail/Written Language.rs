<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Written Language</name>
   <tag></tag>
   <elementGuidId>f16f5e59-111f-4ce1-a567-340654c9de5e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@name = 'writtenLanguage']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//md-select[@id='select_72']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>md-select</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>writtenLanguage</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>placeholder</name>
      <type>Main</type>
      <value>Please select</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-model</name>
      <type>Main</type>
      <value>lessee.writtenLanguage</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-pristine ng-valid ng-empty ng-touched</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-disabled</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>listbox</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-expanded</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-multiselectable</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>select_72</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-invalid</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Please select</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Please select
							
								Afrikaans
							
								Albanian
							
								Arabic
							
								Armenian
							
								Azerbaijani
							
								Basque
							
								Belarusian
							
								Bengali
							
								Bosnian
							
								Bulgarian
							
								Burmese
							
								Catalan
							
								Cebuano
							
								Chinese
							
								Croatian
							
								Czech
							
								Danish
							
								Dutch
							
								English
							
								Esperanto
							
								Estonian
							
								Filipino
							
								Finnish
							
								French
							
								Galician
							
								Georgian
							
								German
							
								Greek
							
								Gujarati
							
								Haitian
							
								Hausa
							
								Hebrew
							
								Hindi
							
								Hmong
							
								Hungarian
							
								Icelandic
							
								Igbo
							
								Indonesian
							
								Irish
							
								Italian
							
								Japanese
							
								Javanese
							
								Kannada
							
								Kazakh
							
								Khmer
							
								Korean
							
								Lao
							
								Latin
							
								Latvian
							
								Lithuanian
							
								Macedonian
							
								Malagasy
							
								Malay
							
								Malayalam
							
								Maltese
							
								Maori
							
								Marathi
							
								Mongolian
							
								Nepali
							
								Norwegian
							
								Nyanja
							
								Persian
							
								Polish
							
								Portuguese
							
								Punjabi
							
								Romanian
							
								Russian
							
								Serbian
							
								Sinhala
							
								Slovak
							
								Slovenian
							
								Somali
							
								Spanish
							
								Sundanese
							
								Swahili
							
								Swedish
							
								Tajik
							
								Tamil
							
								Telugu
							
								Thai
							
								Turkish
							
								Ukrainian
							
								Urdu
							
								Uzbek
							
								Vietnamese
							
								Welsh
							
								Yiddish
							
								Yoruba
							
								Zulu
							
						</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;select_72&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//md-select[@id='select_72']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//md-dialog-content[@id='dialogContent_74']/div/div[5]/md-input-container[2]/md-select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Written language'])[1]/following::md-select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Zulu'])[1]/following::md-select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/md-input-container[2]/md-select</value>
   </webElementXpaths>
</WebElementEntity>
