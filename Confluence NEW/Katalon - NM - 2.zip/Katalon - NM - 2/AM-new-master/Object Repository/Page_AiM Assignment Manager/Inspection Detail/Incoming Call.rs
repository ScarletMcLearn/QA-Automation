<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Incoming Call</name>
   <tag></tag>
   <elementGuidId>04b8438f-6fef-4e0f-830b-f94d4050f313</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@ng-value = '1']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-value</name>
      <type>Main</type>
      <value>1</value>
   </webElementProperties>
</WebElementEntity>
