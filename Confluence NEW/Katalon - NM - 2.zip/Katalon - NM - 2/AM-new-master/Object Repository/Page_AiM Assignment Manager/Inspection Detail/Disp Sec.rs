<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Disp Sec</name>
   <tag></tag>
   <elementGuidId>c7b71b30-01a1-45f3-8df5-8969d2654737</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@ui-view = 'vehicle']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ui-view</name>
      <type>Main</type>
      <value>vehicle</value>
   </webElementProperties>
</WebElementEntity>
