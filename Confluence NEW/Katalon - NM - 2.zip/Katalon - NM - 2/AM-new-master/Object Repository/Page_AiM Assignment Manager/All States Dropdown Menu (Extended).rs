<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>All States Dropdown Menu (Extended)</name>
   <tag></tag>
   <elementGuidId>9a35959f-dd84-417f-9414-10191e43b6ac</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='select_container_489']/md-select-menu/md-content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>md-content</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>_md</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
				All States
				
					Alabama - AL
				
					Alaska - AK
				
					Arizona - AZ
				
					Arkansas - AR
				
					California - CA
				
					Colorado - CO
				
					Connecticut - CT
				
					Delaware - DE
				
					District of Columbia - DC
				
					Florida - FL
				
					Georgia - GA
				
					Hawaii - HI
				
					Idaho - ID
				
					Illinois - IL
				
					Indiana - IN
				
					Iowa - IA
				
					Kansas - KS
				
					Kentucky - KY
				
					Louisiana - LA
				
					Maine - ME
				
					Maryland - MD
				
					Massachusetts - MA
				
					Michigan - MI
				
					Minnesota - MN
				
					Mississippi - MS
				
					Missouri - MO
				
					Montana - MT
				
					Nebraska - NE
				
					Nevada - NV
				
					New Hampshire - NH
				
					New Jersey - NJ
				
					New Mexico - NM
				
					New York - NY
				
					North Carolina - NC
				
					North Dakota - ND
				
					Ohio - OH
				
					Oklahoma - OK
				
					Oregon - OR
				
					Pennsylvania - PA
				
					Puerto Rico - PR
				
					Rhode Island - RI
				
					South Carolina - SC
				
					South Dakota - SD
				
					Tennessee - TN
				
					Texas - TX
				
					Utah - UT
				
					Vermont - VT
				
					Virgin Islands, U.S. - VI
				
					Virginia - VA
				
					Washington - WA
				
					West Virginia - WV
				
					Wisconsin - WI
				
					Wyoming - WY
				
			</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;select_container_489&quot;)/md-select-menu[@class=&quot;_md md-overflow&quot;]/md-content[@class=&quot;_md&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='select_container_489']/md-select-menu/md-content</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='`'])[2]/following::md-content[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Alt'])[2]/following::md-content[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//md-content</value>
   </webElementXpaths>
</WebElementEntity>
