<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Adv Ins Typ DDM Dealer</name>
   <tag></tag>
   <elementGuidId>885dbbd1-55e4-4c70-af6f-05c167285b35</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@value  = '2']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>value </name>
      <type>Main</type>
      <value>2</value>
   </webElementProperties>
</WebElementEntity>
