<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>nav_DashboardRequestRequest ManagementSearc_0aeb54</name>
   <tag></tag>
   <elementGuidId>4ee3eeb5-a1b5-4fdb-a482-70a9b9c4e3c6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>nav</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>layout</name>
      <type>Main</type>
      <value>row</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>layout-align</name>
      <type>Main</type>
      <value>space-between end</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-if</name>
      <type>Main</type>
      <value>isLoggedIn()</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-scope layout-align-space-between-end layout-row flex</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
		
			
				Dashboard
			
			
				Request
				
					
						Request Management
						Search requests
						Add request
					
					
						Organization Management
						Search organizations
						Add organizations
					
				
			
		

		

		
			
				
    
    

				
			
		

		
			
    
    

		
	</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;ng-scope&quot;]/body[1]/div[@class=&quot;global-container light-background&quot;]/header[@class=&quot;dark-background ng-scope layout-column&quot;]/div[@class=&quot;container ng-scope layout-align-space-between-center layout-row&quot;]/nav[@class=&quot;ng-scope layout-align-space-between-end layout-row flex&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//nav</value>
   </webElementXpaths>
</WebElementEntity>
