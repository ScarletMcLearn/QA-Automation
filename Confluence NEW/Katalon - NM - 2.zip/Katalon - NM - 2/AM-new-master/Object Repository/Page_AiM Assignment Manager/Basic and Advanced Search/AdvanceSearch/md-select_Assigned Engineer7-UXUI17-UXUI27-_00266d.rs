<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>md-select_Assigned Engineer7-UXUI17-UXUI27-_00266d</name>
   <tag></tag>
   <elementGuidId>0160a1e7-a35c-450e-9207-ed6f2fae6ccf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//md-select[@id='assigned-engineer']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>md-select</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>placeholder</name>
      <type>Main</type>
      <value>Assigned Engineer</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-model</name>
      <type>Main</type>
      <value>parameters.assignedEngineer</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>assigned-engineer</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-pristine ng-untouched ng-valid flex ng-empty</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Assigned Engineer</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-disabled</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>listbox</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-expanded</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-multiselectable</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-invalid</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Assigned Engineer
					
						7-UXUI1
					
						7-UXUI2
					
						7-UXUI3
					
						7-UXUI4
					
						Aaron Bryant
					
						Aaron McSpadden
					
						Aaron Stadler
					
						Abraham King
					
						Adam Acosta
					
						Adam Clausen (Auction)
					
						Adam Pineault
					
						Adrian Sanchez
					
						Alan Ray
					
						Albern Prevost
					
						Alene Arthur
					
						Alex Benedith
					
						Alex Molina (Auction)
					
						Alexander Milanes
					
						Alexia-Jade Thigpen
					
						Alexis Corral
					
						Allen VanDeWege
					
						Amber Ramos
					
						Andre Santiago
					
						Andrea Kayim
					
						Andres Santos
					
						Andrew Graham
					
						Andrew Jarstfer
					
						Andrew Trevathan
					
						Andrew Vitin
					
						Andy Sieradzki
					
						Angela O'Regan
					
						Anibal Santin
					
						Anil Mohabir
					
						Anthony Digiacomo
					
						Anthony Ferguson
					
						Anthony Grevacio
					
						Anthony Harris
					
						Anthony Hembree
					
						Anthony Mech
					
						Anthony Mielnicki
					
						Anthony Nicolosi
					
						Anthony Pressley
					
						April Talley
					
						Ara Kharazyan
					
						Armando Alejandre
					
						Armando Blanco
					
						Arthur Popick
					
						Asad Rasouli
					
						Ashley Apanewicz
					
						Ashley Bain
					
						Assenith Yap
					
						Augusto Pereira
					
						Aurelio Nepomuceno
					
						Azim Sattar
					
						Benjamin Conze
					
						Benjamin Ogden
					
						Benjamin Schanz
					
						Bienvenido Perez
					
						Bill Woodward
					
						Blake Higa
					
						Bob Bendel
					
						Brad Ott
					
						Branden Christian
					
						Brandon Ibarra
					
						Brandon Jackson
					
						Brandon Preston
					
						Brandon Rost
					
						Brandon St Pierre
					
						Brandon Zarba
					
						Brandt Olson
					
						Bret Daffenberg
					
						Brett Kemeny
					
						Brett Stamper
					
						Brian Bardhi
					
						Brian Baron
					
						Brian Beckrest
					
						Brian Dudley
					
						Brian Kubowski
					
						Brian Mowatt
					
						Brian VanAmburg
					
						Brittany Garcia
					
						Bruce Baker
					
						Bruce Carter
					
						Bryan Erard
					
						Bryan Keeley
					
						Bryan Villavicencio
					
						Bryant Oates
					
						Bryson Estrella
					
						C J VanSyckle
					
						Cameron Gray
					
						Carey Wood
					
						Carl David
					
						Carlos Rodriguez
					
						Carlos Velez (Auction)
					
						Cesar Cammon
					
						Chad Driver
					
						Charles Capizzi
					
						Charles Dacey
					
						Charles Nahas
					
						Chauncey Smiley
					
						Chelsea Davis
					
						Cheryl Kielau
					
						Chris Forsythe
					
						Chris Knapp
					
						Chris Lindenlauf
					
						Chris Nalewyko
					
						Chris Stahulak
					
						Christian Avila
					
						Christian Strickland
					
						Christian Sturgis
					
						Christopher Caldwell
					
						Christopher Fiorella
					
						Christopher Gough
					
						Christopher Jenkins
					
						Christopher Mitchell
					
						Christopher Mullins
					
						Christopher Tay
					
						Clayton Smith
					
						Clive Wallace
					
						Cody Boger
					
						Cody Johnston
					
						Cody Moore
					
						Connie Caruso
					
						Cornell Lee
					
						Cory Smith
					
						Craig Hartman
					
						Craig Simon (Auction)
					
						D'Elijah Dauphin
					
						Dalton Wukasch
					
						Dana Mobley
					
						Daniel Batten
					
						Daniel Cadena
					
						Daniel Cuevas
					
						Daniel Cunningham
					
						Daniel Glock
					
						Daniel Gunnels
					
						Daniel Lopez
					
						Daniel Mason
					
						Daniel Morello
					
						Daniel Nickerson
					
						Daniel Rado
					
						Daniel Titschinger
					
						Daniel Vasquez
					
						Daniel Wawrzaszek
					
						Danielle Gaines-Smith
					
						Danielle Kenyon
					
						Daria Reynozo
					
						Darrell Carr
					
						Darrin Kelley
					
						Dave Robinson
					
						David Coppola
					
						David Flores
					
						David Gilmer
					
						David Gonzalez
					
						David Humphreys
					
						David Kalicharan
					
						David Lacobazzi
					
						David Martinez
					
						David Moore
					
						David Scotland
					
						David Togia
					
						David Whiteheart
					
						De Angelo Allen
					
						Delbert Ball
					
						Denise Malis
					
						Dennis Carrier
					
						Dennis Honaker
					
						Dennis McDonaugh
					
						Denys Magdaichuk
					
						Derek Di Chappari
					
						Derek Layman
					
						Derek Mitchell
					
						Derek Willis
					
						Derrico Welch
					
						Derryck Arnold
					
						Dimitry Yampolsky
					
						Dionna Higgs
					
						Don Crisman
					
						Don Slaughter
					
						Donald Deckert
					
						Donnell Cannon
					
						Donte Stallworth
					
						Dorita Glasco
					
						Douglas Fish
					
						Douglas Fitch
					
						Doyle Jacobson
					
						Dre'Shon Burt
					
						Dunston Owens
					
						Dwayne Henderson
					
						Dylan Lenart
					
						Edgardo Bonilla
					
						Eduard Pak
					
						Edward Desiderio
					
						Edward Paront
					
						Edward Rodriguez
					
						Elijah Sharp
					
						Elizabeth Beth Durham
					
						Elizabeth Guada
					
						Elizabeth Labadie
					
						Elliot Rivera
					
						Elmer Slack
					
						Ely Allgaier
					
						Emily Weitkamp
					
						Eric Badillo
					
						Erik Senhouse
					
						Ernesto Mercado
					
						Esperanza Hernandez
					
						Eugene Yevgeniy Timchenko
					
						Eulises Alarcon
					
						Evan Barlet
					
						Everton Henry
					
						Faith Finch
					
						Frank Bird
					
						Frank Cuccia
					
						Frank Farrugia
					
						Frank Starr
					
						Franklin Rivera
					
						Gary Allor
					
						Gary Ross
					
						Gaspare Mesi
					
						Geanny Melgar
					
						Genaro Diaz Nadal
					
						Geo Bertini (Auction)
					
						George Ali
					
						Gerald Deason
					
						Gerald Frappier
					
						Gerald Monfreda
					
						Gerard Florance
					
						Gerard Portman
					
						Gianni Gilbert
					
						Gilbert Dalli
					
						Gilberto Herrera
					
						Gilberto Phipps
					
						Glen Falvey
					
						Gordon Piel
					
						Greg Sharpes
					
						Gregg Blaha
					
						Guillermo Chavez
					
						Hairon Molina
					
						Hassan Ryan Saadipour
					
						Hector Campusano
					
						Hector Otero (Auction)
					
						Hiram Rivera
					
						Honeyban Gebremedhin
					
						Hope Bradley-Whalen
					
						Isaac Mays
					
						Isaac Morales
					
						Isaiah Like
					
						Isiah Green-Groves
					
						Ivan Gonzalez
					
						Ivan Guzman
					
						Jacob Merrill
					
						Jacqueline Chiariello
					
						Jaime Jusino
					
						James Andary
					
						James Armstrong
					
						James Cieri
					
						James Mack
					
						James Patterson
					
						James Russ High
					
						James Solomon
					
						Jared Crawford
					
						Jared D Suddock
					
						Jared Pena
					
						Jason Agee
					
						Jason Benique
					
						Jason Bosh
					
						Jason Brewer
					
						Jason Kelley
					
						Jason Margolies
					
						Jason McNeil
					
						Jason Reed
					
						Jason Rogers
					
						Jason Sobel
					
						Jason Ullery
					
						Javier Buitrago
					
						Javier Serrano
					
						Jayson Sarmiento
					
						Jedidiah Gaudet
					
						Jeffrey Helsel
					
						Jeffrey Lewis
					
						Jeffrey Medrano
					
						Jemal Ramos
					
						Jennifer Beacon
					
						Jennifer Kiser
					
						Jeremy Smith
					
						Jerry Zachariah
					
						Jessica Laurn
					
						Jessica Prugh
					
						Jesus Geraldino
					
						Jesus Madrid
					
						Jim Cannata
					
						Jim Silvia
					
						Jody Mosby
					
						Joe Caraballo
					
						Joesph Guido
					
						Johanna Penuela
					
						John Avdellis
					
						John Barrett
					
						John Hunt
					
						John JD Douglas
					
						John Kirsch
					
						John Lamb
					
						John Lasorella
					
						John Olsen
					
						John Savage
					
						John Tankersly
					
						John Tinnin
					
						Johnny Dickens
					
						Johnny Lagore
					
						Johnny Nino
					
						Jonathan Bouley
					
						Jonathan Contreras
					
						Jonathan McCullough
					
						Jonathan Relevo
					
						Jonathon Soto
					
						Jordan Veal
					
						Jorge Delgado
					
						Jorge Gonzalez
					
						Jorge Pena
					
						Jorge Ramos
					
						Jorge Sanchez
					
						Jose Torres
					
						Joseph Aquino
					
						Joseph Bailey
					
						Joseph Egolf
					
						Joseph Garrison
					
						Joseph Hannis
					
						Joseph Johnson
					
						Joseph Lowry
					
						Joseph Mancusi
					
						Joseph Millan
					
						Joseph Nardolillo
					
						Joseph Pruett
					
						Joseph Rehall
					
						Joseph Rivers
					
						Joshua Aquino
					
						Joshua Chilcott
					
						Joshua Cline
					
						Joshua Flores
					
						Joshua Howard
					
						Joshua Lawson
					
						Joy Fusco
					
						Joyce Javier
					
						Juan Barillas
					
						Juan Carlos Aguilar
					
						Juan Flores
					
						Juan Garcia
					
						Juan Gonzalez
					
						Juanita Jones
					
						Julie May
					
						Julio Montes
					
						Julio Munoz
					
						Julio Ruiz
					
						Justin Brand
					
						Justin Connally
					
						Justin Horvath (IC)
					
						Justin Maples
					
						Justin Matelski
					
						Justin Rutherford
					
						Karl Joseph
					
						Kathrine Gilmer
					
						Kathy Dobson
					
						Kauri Qualls
					
						Kauri Qualls North East, New Jersey
					
						Kaushalya Pussedeniya
					
						Kayla Meadows
					
						Keith Petrocik
					
						Keith Sheehan
					
						Keith Tanzi
					
						Kelvin McCree
					
						Kendell Northcutt
					
						Kennedi Speight
					
						Kenneth Chambers
					
						Kenneth Jones (Auditor)
					
						Kenneth Raia
					
						Kenny Garcia
					
						Kevin Bohner
					
						Kevin Carter
					
						Kevin Grech
					
						Kevin James
					
						Kevin O'Connor
					
						Kevin Seeley
					
						Kevin Walker
					
						Khali Griffin
					
						Kieran Goins
					
						Kong Yang
					
						Konpheng Lee
					
						Kristina Leibouvitz
					
						Kristopher Robin
					
						Kyle Crawford
					
						Lance Sylvis
					
						LaQuinina Wheeler
					
						Larry Strickland
					
						Larry Woodruff
					
						Lauren Bechtel
					
						Lawrence Hofing (Auction)
					
						Lawrence Morgan
					
						Lawrence Morgan Sr.
					
						Lawrence Moronez
					
						Leah Menk
					
						Leaton Barrett
					
						Leon Fleury
					
						Leon Philson
					
						Leon Reed
					
						Leonard Lombardo (Auction)
					
						Leslie Meola
					
						Lester Bishop
					
						Levan Cuthbert
					
						Lisa Detorakis
					
						Lisa Makowski
					
						Logan Evans
					
						Logan Hinnant
					
						Logen VanArkel
					
						Lorenzo Baca
					
						Luis Baldazo
					
						Luis Felipe
					
						Luis Raya Flores
					
						Luke Weese
					
						Lynn Speakman
					
						Lynne Elardo
					
						Mansfield Cody
					
						Marc Altman
					
						Marc Weiner
					
						Marcelo Premoli
					
						Marco Diaz (Auction)
					
						Marco Garcia
					
						Marcos Lobaina
					
						Marcus Anderson
					
						Maria Linn
					
						Maricarmen Carranza
					
						Mario Rivera
					
						Mark Magnuson
					
						Mark Townsend
					
						Mark Warren
					
						Marlene Easters
					
						Marvin Gonzalez
					
						Mateo Dominguez
					
						Mathew Baker
					
						Matthew Fundis
					
						Matthew Pichitino
					
						Matthew Smith
					
						Maxim Rylov
					
						Megan Calcagno
					
						Melanie Benson
					
						Melissa Acosta
					
						Melissa McCoy
					
						Melissa New
					
						Melissa Roberts
					
						Melissa Roberts
					
						Melvin Chavez
					
						Michael Antoine
					
						Michael Berns
					
						Michael Berwick
					
						Michael Castranuovo
					
						Michael Doug Pack
					
						Michael Falkowski
					
						Michael Garcia
					
						Michael Gonzalez
					
						Michael Machion
					
						Michael McCloskey
					
						Michael McDonald
					
						Michael McGregor
					
						Michael Mullins
					
						Michael Smith II
					
						Micheal Washington
					
						Michele Gordy
					
						Michelle Brock
					
						Michelle Crosby
					
						Miguel Greer
					
						Mike Eggers
					
						Misty Blair
					
						Mitchell Snell
					
						Moose Mustavah Ramkalup
					
						Narith Kol
					
						Nathan Strouse
					
						Nehemiah Long
					
						Neil Dookeeram
					
						Neil Magnuson
					
						Nelson Birdsong
					
						Newton Wallace
					
						Nicholas Leoni
					
						Nicholas Monfreda
					
						Nicholas Smith
					
						Nicholas Washington
					
						Nick Cunanan
					
						Nicklas Manasarian
					
						Nik O'Regan
					
						Noel Roman
					
						Noel Rosario
					
						Otis Cuspard
					
						Pablo Amezaga
					
						Pablo Sanchez
					
						Pam Hierdahl
					
						Patrick Donnelly
					
						Patrick McDonald
					
						Patrick Power
					
						Paul Gerdell
					
						Paul Perez
					
						Paul Rempala
					
						Paul Varno
					
						Pedro Mendoza
					
						Peter Bicevskis
					
						Peter Johnson
					
						Peter Valdes
					
						Phillip Friend
					
						Portia Griffin
					
						Rafael Lozada Berrios
					
						Rafael Pio
					
						Rafael Roman
					
						Rainier Bonachea
					
						Rance Like
					
						Rance Like 2
					
						Randall Purchase
					
						Raymond Eller
					
						Raymond Flores
					
						Raymond Gouin
					
						Raymond Guardiano
					
						Raymond Muller (Contractor)
					
						Raymond Sharp
					
						Raymond Villegas
					
						Reggie Anders
					
						Reilly Blank
					
						Reinaldo Jimenez Jr. (Auction)
					
						Remedios Armenta
					
						Ricardo Diaz
					
						Richard Adams
					
						Richard Harmon
					
						Richard King
					
						Richard Rick Rodriguez
					
						Richard Rodriguez
					
						Richard Vang
					
						Richard Veen
					
						Richard Whitten (Auction)
					
						Riley Szydloski
					
						Rob Papelbon
					
						Robert Cox
					
						Robert Dickerhoff
					
						Robert Dubato
					
						Robert Garguilo
					
						Robert Greenfield
					
						Robert Guth
					
						Robert Harmon
					
						Robert Jenkins
					
						Robert LaFollette
					
						Robert Lewis
					
						Robert McGill
					
						Robert Monastero
					
						Robert Panelley
					
						Robert Plaugher
					
						Robert Rajski
					
						Robert Sullivan
					
						Robert Williams
					
						Roberto Garcia
					
						Rodney Buck Purchase
					
						Roger Moore
					
						Roger Thigpen
					
						Ron Speight (Auction)
					
						Ronald Dajoh
					
						Ronald Torres
					
						Ross Cardniale
					
						Roy Bonifacio Rodriguez
					
						Rudy Wood
					
						Russell Gonzales
					
						Ryan Martin
					
						Ryan Morrison
					
						Sabrina Buck
					
						Sailesh Raj
					
						Samantha Sanchez
					
						Sameh Soliman
					
						Samuel Gregory
					
						Sandy Allen
					
						Sang Tinn Saephan
					
						Sarn Saechao
					
						Savek Arakelian
					
						Savino Casarella (Contractor)
					
						Scott Hopkins (AM)
					
						Scott James
					
						Scott Meisel
					
						Scott Pepke
					
						Scott Price
					
						Scott Pugh
					
						sdfsd
					
						Sean Burch
					
						Sean Collins
					
						Sean Crawford
					
						Sean LaForce
					
						Sergio Alvarez
					
						Sergio Alvarez North East, New Jersey
					
						Shane Pope (Auction)
					
						Sharif Subhan
					
						Sharon Jones
					
						Sharon McDonaugh
					
						Sharon Vasey
					
						Shawn McGeehan
					
						Shawn McGeehan North East, Pennsylvania
					
						Shawna Hills
					
						Stacey Hopkins
					
						Stacey Hopkins North East, Pennsylvania
					
						Stephen Gregoire
					
						Stephen King
					
						Stephen Squicciarini
					
						Stephen Sylvis
					
						Sterling Walton
					
						Steve Battaglia
					
						Steve Engel
					
						Steve Luszcz
					
						Steve Sayegh
					
						Steven Brown
					
						Steven Henne
					
						Steven Palumbo
					
						Steven Reyes
					
						Steven Sanchez
					
						Steven Taylor
					
						Steven Tjan
					
						Stewart Delgado
					
						Susan Cowell
					
						Tanner Holt
					
						Tara Perez (Auction)
					
						Ted Dillion
					
						Theogene Downs
					
						Thomas Adams
					
						Thomas Cunningham
					
						Thomas Glinski
					
						Thomas Macioce
					
						Thomas Magee
					
						Thomas Scheuering
					
						Thomas Sherry
					
						Thomas Shubsda
					
						Tim Coady
					
						Tim Cote
					
						Tim Melton
					
						Timothy Baughan
					
						Timothy Strand
					
						Timothy Wahba
					
						Todd Wagner
					
						Tommy Carroll
					
						Tor Nelson
					
						Torrey Fenn
					
						Tracy Cadden
					
						Travis Hewitt
					
						Trevor Barth
					
						Tristan Gooch
					
						Troy Brisbine
					
						Tuan Le
					
						Tyler Gayden
					
						Tyler Melvin
					
						Tyler Schroeder
					
						Tyrone Campbell
					
						Victor Alejandre
					
						Victor Espinosa (Auction)
					
						Victor Garcia
					
						Victor Rivera
					
						Victoria Smith
					
						Vincent Cruz
					
						Wade Kriner
					
						Warren Sweeney
					
						Wayne Anderson
					
						Wazed Muhammed
					
						Wesley Dow
					
						Wilfran Rondon
					
						Wilfredo Rodriguez
					
						Wilfredo Rodriguez North East, Pennsylvania
					
						William Burr
					
						William Jameson
					
						William Jester
					
						William Knoth (Auction)
					
						William Love (Auction)
					
						William Owen
					
						William Schwartz
					
						William Wyland
					
						Xavier Molina
					
						Zachary Smith
					
				</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;assigned-engineer&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//md-select[@id='assigned-engineer']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='search-container']/form/section/div[15]/md-input-container/md-select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Assigned Engineer'])[1]/following::md-select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tentative'])[1]/following::md-select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[15]/md-input-container/md-select</value>
   </webElementXpaths>
</WebElementEntity>
