<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>md-input-container_State originally leased _539e4c</name>
   <tag></tag>
   <elementGuidId>27d44d09-8d97-4ce5-b326-2401ef69d7a0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content-container']/div/div/form/section/div/div[2]/div/div[6]/md-input-container</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>md-input-container</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>flex</name>
      <type>Main</type>
      <value>30</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-if</name>
      <type>Main</type>
      <value>isHomeRequest()</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-scope md-input-has-placeholder flex-30 md-input-invalid</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			State originally leased in
			Please select
				
					Alabama - AL
				
					Alaska - AK
				
					Arizona - AZ
				
					Arkansas - AR
				
					California - CA
				
					Colorado - CO
				
					Connecticut - CT
				
					Delaware - DE
				
					District of Columbia - DC
				
					Florida - FL
				
					Georgia - GA
				
					Hawaii - HI
				
					Idaho - ID
				
					Illinois - IL
				
					Indiana - IN
				
					Iowa - IA
				
					Kansas - KS
				
					Kentucky - KY
				
					Louisiana - LA
				
					Maine - ME
				
					Maryland - MD
				
					Massachusetts - MA
				
					Michigan - MI
				
					Minnesota - MN
				
					Mississippi - MS
				
					Missouri - MO
				
					Montana - MT
				
					Nebraska - NE
				
					Nevada - NV
				
					New Hampshire - NH
				
					New Jersey - NJ
				
					New Mexico - NM
				
					New York - NY
				
					North Carolina - NC
				
					North Dakota - ND
				
					Ohio - OH
				
					Oklahoma - OK
				
					Oregon - OR
				
					Pennsylvania - PA
				
					Puerto Rico - PR
				
					Rhode Island - RI
				
					South Carolina - SC
				
					South Dakota - SD
				
					Tennessee - TN
				
					Texas - TX
				
					Utah - UT
				
					Vermont - VT
				
					Virgin Islands, U.S. - VI
				
					Virginia - VA
				
					Washington - WA
				
					West Virginia - WV
				
					Wisconsin - WI
				
					Wyoming - WY
				
			
			
				You did not select a state of origin
			
		
					 - 
				</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content-container&quot;)/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;inspection-request ng-scope&quot;]/form[@class=&quot;layout-column ng-invalid ng-invalid-required ng-valid-crm-is-positive-int ng-valid-crm-exact-length ng-invalid-crm-zip-validator ng-dirty ng-valid-mindate ng-valid-maxdate ng-valid-filtered ng-valid-valid ng-valid-lessee-days-past-maturity-date ng-valid-vin-is-valid ng-valid-minlength ng-valid-parse ng-submitted&quot;]/section[1]/div[@class=&quot;ng-scope layout-column&quot;]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;lessee-info section-content ng-scope flex&quot;]/div[@class=&quot;layout-xs-column layout-row&quot;]/md-input-container[@class=&quot;ng-scope md-input-has-placeholder flex-30 md-input-invalid&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content-container']/div/div/form/section/div/div[2]/div/div[6]/md-input-container</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Maturity date'])[1]/following::md-input-container[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Zulu'])[2]/following::md-input-container[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/md-input-container</value>
   </webElementXpaths>
</WebElementEntity>
