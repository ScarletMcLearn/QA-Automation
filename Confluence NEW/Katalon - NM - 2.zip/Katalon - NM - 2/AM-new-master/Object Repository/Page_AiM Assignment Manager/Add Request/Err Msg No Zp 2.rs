<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Err Msg No Zp 2</name>
   <tag></tag>
   <elementGuidId>fb1af011-9b6f-4e3e-be44-ac325fc594a5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@ng-message = 'required']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;content-container&quot;]/div/div/form/section/section/div[1]/section/div[3]/div[2]/div[2]/md-input-container[3]/div[2]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-message</name>
      <type>Main</type>
      <value>required</value>
   </webElementProperties>
</WebElementEntity>
