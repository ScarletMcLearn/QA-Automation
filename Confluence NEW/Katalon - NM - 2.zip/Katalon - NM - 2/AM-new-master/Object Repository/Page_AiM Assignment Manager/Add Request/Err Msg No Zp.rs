<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Err Msg No Zp</name>
   <tag></tag>
   <elementGuidId>5b519d35-47fe-4c4c-8690-8b1c594e8039</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@ng-message = 'required']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;content-container&quot;]/div/div/form/section/div/div[2]/div/div[2]/div[2]/div/md-input-container[3]/div[2]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-message</name>
      <type>Main</type>
      <value>required</value>
   </webElementProperties>
</WebElementEntity>
