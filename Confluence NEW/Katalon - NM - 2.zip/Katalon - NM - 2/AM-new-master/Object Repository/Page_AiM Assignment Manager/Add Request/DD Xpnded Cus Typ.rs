<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DD Xpnded Cus Typ</name>
   <tag></tag>
   <elementGuidId>d26be15f-9112-462c-a24c-387831010178</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@ng-value = 'customer']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-value</name>
      <type>Main</type>
      <value>customer</value>
   </webElementProperties>
</WebElementEntity>
