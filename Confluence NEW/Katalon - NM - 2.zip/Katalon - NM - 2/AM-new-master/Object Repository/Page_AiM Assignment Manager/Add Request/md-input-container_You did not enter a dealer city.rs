<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>md-input-container_You did not enter a dealer city</name>
   <tag></tag>
   <elementGuidId>b094db7d-1e98-4f53-a3a8-2d217c445f64</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content-container']/div/div/form/section/div/div[2]/div/div[2]/div[2]/div/md-input-container</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>md-input-container</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>md-input-has-placeholder md-input-invalid</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
					
					
						You did not enter a dealer city
					
				</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content-container&quot;)/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;inspection-request ng-scope&quot;]/form[@class=&quot;layout-column ng-invalid ng-invalid-required ng-valid-crm-is-positive-int ng-valid-crm-exact-length ng-invalid-crm-zip-validator ng-dirty ng-valid-mindate ng-valid-maxdate ng-valid-filtered ng-valid-valid ng-valid-lessee-days-past-maturity-date ng-valid-vin-is-valid ng-valid-minlength ng-valid-parse ng-submitted&quot;]/section[1]/div[@class=&quot;ng-scope layout-column&quot;]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;lessee-info section-content ng-scope flex&quot;]/div[@class=&quot;layout-row&quot;]/div[@class=&quot;layout-column&quot;]/div[@class=&quot;layout-xs-column layout-row&quot;]/md-input-container[@class=&quot;md-input-has-placeholder md-input-invalid&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content-container']/div/div/form/section/div/div[2]/div/div[2]/div[2]/div/md-input-container</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Canada - CA'])[1]/following::md-input-container[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mexico - MX'])[1]/following::md-input-container[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='State'])[1]/preceding::md-input-container[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/div/md-input-container</value>
   </webElementXpaths>
</WebElementEntity>
