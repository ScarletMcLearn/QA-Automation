<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>IR Pg Hdin</name>
   <tag></tag>
   <elementGuidId>88070031-5365-424f-802c-68c0c825e1ee</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@h1 = 'Inspection Request']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;content-container&quot;]/div/div/h1/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>h1</name>
      <type>Main</type>
      <value>Inspection Request</value>
   </webElementProperties>
</WebElementEntity>
