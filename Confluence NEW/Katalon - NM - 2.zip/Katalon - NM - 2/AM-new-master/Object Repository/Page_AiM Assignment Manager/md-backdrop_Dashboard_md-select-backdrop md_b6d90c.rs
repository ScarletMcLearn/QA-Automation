<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>md-backdrop_Dashboard_md-select-backdrop md_b6d90c</name>
   <tag></tag>
   <elementGuidId>94ee5f53-fbed-4e48-82f4-5f2a8b446725</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//md-backdrop</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>md-backdrop</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>md-select-backdrop md-click-catcher ng-scope</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;ng-scope&quot;]/body[1]/md-backdrop[@class=&quot;md-select-backdrop md-click-catcher ng-scope&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//md-backdrop</value>
   </webElementXpaths>
</WebElementEntity>
