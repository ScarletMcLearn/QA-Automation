package lss
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable
import io.cucumber.tagexpressions.TagExpressionParser.True

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

import cucumber.api.java.en.And
import cucumber.api.java.en.Given
import cucumber.api.java.en.Then
import cucumber.api.java.en.When



class LSS_Steps {
	/**
	 * The step definitions below match with Katalon sample Gherkin steps
	 */
	@Given("I want to write a step with (.*)")
	def I_want_to_write_a_step_with_name(String name) {
		println name
	}

	@When("I check for the (\\d+) in step")
	def I_check_for_the_value_in_step(int value) {
		println value
	}

	@Then("I verify the (.*) in step")
	def I_verify_the_status_in_step(String status) {
		println status
	}




	@Given ('Browser is opened')
	def open_browser() {
		WebUI.openBrowser('');
	}


	@And ('navigated to AIM Inspect Site')
	def go_to_aim_inspect() {
		//		WebUI.navigateToUrl(GlobalVariable.url)

		WebUI.navigateToUrl('https://selfschedule-qa.aiminspect.com')

	}


	@Then ('Lessee selfschedule site is displayed')
	def lss_displayed() {

		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/LSSContent'), 0
				)

		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Login_URL'), 0
				)
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Submit_Button'), 0
				)
	}




	@And ('Home page has 3 sections: Header, Body and Footer')
	def home_page_sections() {

		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Footer')
				, 0
				)

		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Body')
				, 0
				)


		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Login_URL')
				, 0
				)


		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Login_URL')
				, 0
				)

		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Navbar')
				, 0
				)

		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Navbar_AboutAimLink')
				, 0
				)


		WebUI.verifyElementPresent(

				findTestObject('Object Repository/LSS/HomePage/Navbar_RegionIcon')
				, 0
				)

		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Navbar_SiteLogo')
				, 0
				)

		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Submit_Button')
				, 0
				)
	}

	//	@And ('Home page has 3 sections: Header, Body and Footer')
	//	def home_page_sections() {
	//
	//
	//
	//
	//
	//
	////
	//	}


	@Given ('I am on LSS Home page Header section')
	def on_lss_home_page() {
		WebUI.openBrowser(GlobalVariable.url)

		WebUI.navigateToUrl('https://selfschedule-qa.aiminspect.com')

	}




	@And ('I see site Logo')
	def lss_logo() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Navbar_SiteLogo')
				, 0
				)
	}

	@And ('I see the link "About AiM"')
	def abt_aim() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Navbar_AboutAimLink')
				, 0
				)
	}

	@And ('clicking on the link goes to About Page')
	def navigates_to_about_page() {

		WebUI.click(findTestObject('Object Repository/LSS/HomePage/Navbar_AboutAimLink'))

		WebUI.delay(5)

		WebUI.switchToWindowTitle('Alliance Inspection Management |   About Us')

		assert WebUI.getUrl() == 'http://homepage.aiminspections.com/about-us/'
	}



	//	Given
	//	@Given ('I am on LSS Home page Body section')
	//	def on_lss_home_page_body() {
	////		WebUI.navigateToUrl(GlobalVariable.url)
	//
	//		WebUI.navigateToUrl('https://selfschedule-qa.aiminspect.com')
	//
	//	}

	@Given ('I am on LSS Home page Body section')
	def on_lss_home_page_body() {
		WebUI.openBrowser('')
		WebUI.navigateToUrl(GlobalVariable.url)
	}


	@And ('Body section has the followings: Title, Paragraph, Button and Link')
	def body_has_components() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Title')
				, 0
				)

		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Paragraph')
				, 0
				)

		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Submit_Button')
				, 0
				)


	}




	@Given ('I am on LSS Home page Footer section')
	def on_lss_home_page_footer() {
		WebUI.openBrowser('')
		WebUI.navigateToUrl(GlobalVariable.url)
	}


	@And ('Footer section contains 3 links and Text')
	def footer_section_components() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Footer - Contact Link')
				, 0
				)

		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Footer - Privacy Link')
				, 0
				)


		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Footer -Terms of Service Link')
				, 0
				)
	}


	@And ('Footer Text: "© 2019 Alliance Inspection Management"')
	def footer_text() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/HomePage/Footer - Copyright'),
				0)

	}



	@Given ('current page is Home Page')
	def lss_home_page() {
		WebUI.openBrowser('')
		WebUI.navigateToUrl(GlobalVariable.url)
	}



	@And ("clicked on Schedule Appointment button")
	def click_app_shedule_btn() {
		WebUI.click(
				findTestObject('Object Repository/LSS/HomePage/Submit_Button')
				)
	}


	@Then ('LSS Log in site is displayed')
	def lss_login_site() {
		assert WebUI.getUrl() == 'https://selfschedule-uat.aiminspect.com/log-in';
	}




	@And ("login link is clicked")
	def click_app_shedule_lnk() {
		WebUI.click(
				findTestObject('Object Repository/LSS/HomePage/Login_URL')
				)
		WebUI.sleep(5)

		//		 element = findTestObject('Object Repository/LSS/HomePage/Login_URL')
		//		WebUI.executeJavaScript("arguments[0].click()", element)
	}



	@Given ('I am on Login page')
	def go_to_login_pg() {
		WebUI.openBrowser('')
		WebUI.navigateToUrl(GlobalVariable.url)

		WebUI.click(
				findTestObject('Object Repository/LSS/HomePage/Login_URL')
				)
		WebUI.sleep(5)
	}





	@And ('I see Two text fields: VIN and Account number')
	def found_vin_acc_field() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoginPage/AccountNumber_Field')
				, 0)

		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoginPage/VIN_Field')
				, 0)

	}
	@And ('a button: "Get started"')
	def get_started_btn() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoginPage/GetStarted_Btn')
				, 0)
	}

	@And ('a link: "Need help?"')
	def need_help_link() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoginPage/NeedHelpURL')
				, 0)
	}



	@Given ('current page is LSS Log in')
	def now_on_lss_login() {
		WebUI.openBrowser('')
		WebUI.navigateToUrl(GlobalVariable.url)

		WebUI.click(
				findTestObject('Object Repository/LSS/HomePage/Login_URL')
				)
		WebUI.sleep(5)
	}

	@And ('no VIN is entered')
	def no_vin() {

	}

	@And ('no Account number is entered')
	def no_acc() {

	}

	@And ('Get Started is clicked')
	def click_get_started() {
		WebUI.click(
				findTestObject('Object Repository/LSS/LoginPage/GetStarted_Btn')
				)

		WebUI.sleep(5)
	}

	@Then ('error-message displays "Enter a Valid VIN"')
	def enter_valid_vin() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoginPage/Enter_Valid_Vin_ErrorMessage')
				, 0)
	}

	@And ('"Enter a valid account number"')
	def enter_valid_acc() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoginPage/Enter_Valid_Acc_ErrorMessage')
				, 0)
	}


	@And ('VIN is entered')
	def enter_vin() {
		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoginPage/VIN_Field')
				, GlobalVariable.vin_pending)

	}


	@And ('entered a scheduled vin')
	def enter_sched_vin() {
		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoginPage/VIN_Field')
				, GlobalVariable.vin_scheduled)

	}


	@And ('entered a completed vin')
	def enter_completed_vin() {
		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoginPage/VIN_Field')
				, GlobalVariable.vin_completed)

	}


	@And ('Get Started button is clicked')
	def click_get_started_2() {
		WebUI.click(
				findTestObject('Object Repository/LSS/LoginPage/GetStarted_Btn')
				)

		WebUI.sleep(5)
	}


	@Then ('error-message displays "Enter a valid account number"')
	def enter_valid_acc_error() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoginPage/Enter_Valid_Acc_ErrorMessage')
				, 0)
	}


	@And ('Account number is entered')
	def acc_no_entered() {
		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoginPage/AccountNumber_Field')
				, GlobalVariable.accountno_pending)

	}



	@And ('entered a scheduled account')
	def completed_acc_no_entered() {
		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoginPage/AccountNumber_Field')
				, GlobalVariable.account_scheduled)

	}


	@And ('entered a completed account')
	def shed_acc_no_entered() {
		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoginPage/AccountNumber_Field')
				, GlobalVariable.accountno_completed)

	}


	@Then ('error-message displays "Enter a valid VIN"')
	def enter_vin_error() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoginPage/Enter_Valid_Vin_ErrorMessage')
				, 0)
	}


	@Then ('error-message displays "Enter a valid VIN" 2')
	def enter_vin_error_2() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoginPage/Enter_Valid_Vin_ErrorMessage 2')
				, 0)
	}



	@And ('entered an invalid vin')
	def give_invalid_vin() {

		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoginPage/VIN_Field')
				, GlobalVariable.invalid_vin)

	}

	@And ('entered an invalid account')
	def give_invalid_acc() {

		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoginPage/AccountNumber_Field')
				, GlobalVariable.invalid_acc)

	}



	@Then ('error-message displayed "We were unable to match the VIN and account number you entered. Please check your entries and try again."')
	def unable_to_match_vin_and_account() {

		WebUI.sleep(5)

		WebUI.verifyElementPresent(

				findTestObject('Object Repository/LSS/LoginPage/Unable To Match VIN and Account')
				, 0)
	}


	@And ('entered a valid vin')
	def give_valid_vin() {

		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoginPage/VIN_Field')
				, GlobalVariable.vin_pending)

	}



	@And ('entered a valid account')
	def give_valid_account() {
		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoginPage/AccountNumber_Field')
				, GlobalVariable.accountno_pending)
	}


	@Then ('Account Info page dispalys')
	def acc_info_pg_shown() {

		WebUI.delay(60)


		assert WebUI.getUrl() == 'https://selfschedule-uat.aiminspect.com/account'
	}



	@And ("page title display: Hello, and Lessee's 1st Name")
	def page_disp_title() {
		//		WebUI.verifyElementPresent(
		//				findTestObject('Object Repository/LSS/LoggedInPage/HelloHeading')
		//				, 0)
		def temp = WebUI.getText(findTestObject('Object Repository/LSS/LoggedInPage/HelloHeading'))

		assert temp.contains('Hello') == true

		//		println (WebUI.getText(findTestObject('Object Repository/LSS/LoggedInPage/HelloHeading')))

	}







	@And ("Vehicle's Year / Make / Model displays")
	def vehicle_info_shown() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoggedInPage/VehicleMakeModelYear')
				, 0)

		//			WebUI.verifyElementPresent(
		//				findTestObject('Object Repository/LSS/LoggedInPage/MainPhoto')
		//				, 0)
		//
		//			WebUI.verifyElementPresent(
		//				findTestObject('Object Repository/LSS/LoggedInPage/MainPhoto')
		//				, 0)
	}




	@And ('VIN Displays')
	def vin_dispd() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoggedInPage/VehicleVIN')
				, 0)
	}


	@And ('Inspection Date displays')
	def isp_date_dispd() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoggedInPage/VehicleInspectionDate')
				, 0)
	}


	@And ('Status: "Completed" displays')
	def status_completed_dispd() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoggedInPage/VehicleStatusCompleted')
				, 0)
	}


	@And ('Button: "View CR" displays')
	def view_cr_shown() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoggedInPage/ViewCRButton')
				, 0)
	}


	@Then ('Inspection Overview Info page dispalys')
	def ainspction_overview_pg_shown() {

		WebUI.delay(50)


		assert WebUI.getUrl() == 'https://selfschedule-uat.aiminspect.com/condition'
	}



	@And ('header-text display: Overview')
	def overview_header_text() {


		println (WebUI.getText(
				findTestObject('Object Repository/LSS/LoggedInPage/OverviewHeader')
				))

		def temp = WebUI.getText(
				findTestObject('Object Repository/LSS/LoggedInPage/OverviewHeader')
				)

		assert temp.contains('Overview') == true


	}



	@And ('main-photo displays')
	def main_pic_displayed() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoggedInPage/MainPhoto')
				, 0)
	}



	@And('nav-tabs: "STANDARD PHOTOS" selected by default displays')
	def standard_photos() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoggedInPage/VehicleStandardPhoto')
				, 0)
	}


	@And ('all the photos taken by the inspector dispalys')
	def all_photos_displayed() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoggedInPage/VehicleAllPhoto')
				, 0)
	}


	@And ('nav-tabs: "DAMAGE PHOTOS" displays')
	def damage_photos_tab() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoggedInPage/VehicleDamagePhoto')
				, 0)
	}


	@And ('User can view the PDF file')
	def see_pdf() {
		WebUI.click(
				findTestObject('Object Repository/LSS/LoggedInPage/ViewCRButton')
				)
	}




	@Then("main-photo\\/vehicle-photo is clicked a Overlay Modal Portal displays")
	def main_pic_click_overlay_displayed() {
		WebUI.click(
				findTestObject('Object Repository/LSS/LoggedInPage/VehicleMainPhoto')
				)


		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoggedInPage/VehicleMainPicOverlay')
				, 0)
	}



	@And ('Overlay Modal Portal image title dispalys')
	def overlay_image_title() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoggedInPage/VehicleOverlayModelImageTitle')
				, 0)
	}




	@And ('Image displays')
	def image_displays() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoggedInPage/RiliImg')
				, 0)
	}


	@And ('Zoom in, Zoom out and Close button displays')
	def img_buttons_shown() {
		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoggedInPage/ImgClose')
				, 0)

		WebUI.verifyElementPresent(
				findTestObject('Object Repository/LSS/LoggedInPage/ImgZoomIn')
				, 0)
	}


	@And ('"Zoom in" and "Close" button are active on initial load')
	def verify_active_controls() {
		WebUI.verifyElementClickable(
				findTestObject('Object Repository/LSS/LoggedInPage/ImgClose')
				)

		WebUI.verifyElementClickable(
				findTestObject('Object Repository/LSS/LoggedInPage/ImgZoomIn')
				)


	}

	@When ('Zoom in button is clicked it Zooms the Photo * 1x')
	def click_zoom_img() {
		WebUI.click(
				findTestObject('Object Repository/LSS/LoggedInPage/ImgZoomIn')
				)
	}


	@And ('Zoom in can be 3x times')
	def click_zoom_img_2px() {
		WebUI.click(
				findTestObject('Object Repository/LSS/LoggedInPage/ImgZoomIn')
				)

		WebUI.click(
				findTestObject('Object Repository/LSS/LoggedInPage/ImgZoomIn')
				)

	}

	@And ('Zoom out button gets active')
	def zoom_out_active() {
		WebUI.verifyElementClickable(
				findTestObject('Object Repository/LSS/LoggedInPage/ImgZoomOut')
				)

	}

	@When ('Close button is clicked the "Overlay Modal Portal" closes')
	def click_close() {
		WebUI.click(
				findTestObject('Object Repository/LSS/LoggedInPage/ImgClose')
				)

		WebUI.verifyElementNotPresent(
				findTestObject('Object Repository/LSS/LoggedInPage/RiliImg')
				, 0)
	}



	@And ("'something is wrong' button is clicked")
	def sth_is_wrong_clicked(){
		WebUI.click(
				findTestObject('Object Repository/LSS/LoggedInPage/SthIsWrongBtn')
				)
	}



	@Then ('get-assistance page is displayed')
	def get_assistance_page_displayed() {
		WebUI.delay(5)


		assert WebUI.getUrl() == 'https://selfschedule-uat.aiminspect.com/get-assistance'
	}



	@And ('confirm button is clicked')
	def click_confirm() {
		WebUI.click(
				findTestObject('Object Repository/LSS/LoggedInPage/AccountConfirmInfoBtn')
				)
	}

	@Then ('Contact info page is displayed')
	def cont_info_pg_disp() {
		WebUI.delay(5)


		assert WebUI.getUrl() == 'https://selfschedule-uat.aiminspect.com/contact'
	}


	@And ("the 'continue' button is disabled")
	def cont_btn_disb() {
		WebUI.verifyElementNotClickable(
				findTestObject('Object Repository/LSS/LoggedInPage/ContactInfoContinueBtn')
				)
	}



	@And ('continue button is enabled')
	def cont_btn_enbld() {
		WebUI.verifyElementClickable(
				findTestObject('Object Repository/LSS/LoggedInPage/ContactInfoContinueBtn')
				)
	}


	@When ('phone number "1234567890" is entered')
	def phone_entered() {
		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoggedInPage/ContactInfoPhoneInput')
				, "1234567890")
	}


	@And ('email entered is "r@p.com"')
	def email_entered() {
		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoggedInPage/ContactInfoEmailInput')
				, "r@p.com")
	}


	@And ('continue button is clicked')
	def click_cont_cont_info() {
		WebUI.click(
				findTestObject('Object Repository/LSS/LoggedInPage/ContactInfoContinueBtn')
				)
	}


	@Then ('inspection location page is displayed')
	def insp_loc_pg_disp() {
		WebUI.delay(5)


		assert WebUI.getUrl() == 'https://selfschedule-uat.aiminspect.com/location'

	}


	@And ("phone type 'work' is selected")
	def phone_type_work_selected() {
		WebUI.selectOptionByIndex(findTestObject(
				'Object Repository/LSS/LoggedInPage/ContactInfoPhoneDDMenu'
				), 1)
	}



	@When ('focus phone field')
	def focus_on_phone() {
		WebUI.click(
				findTestObject('Object Repository/LSS/LoggedInPage/ContactInfoPhoneInput')
				)
	}


	@And ('click away from the phone field')
	def click_away() {
		WebUI.click(
				findTestObject('Object Repository/LSS/LoggedInPage/ContactInfoTitle')
				)
	}


	@Then ('error message 1 is displayed')
	def one_error() {
		WebUI.verifyElementClickable(
				findTestObject('Object Repository/LSS/LoggedInPage/ContactInfoNoPhoneError')
				)
	}

	@And ('focus on email field')
	def focus_email() {
		WebUI.click(
				findTestObject('Object Repository/LSS/LoggedInPage/ContactInfoEmailInput')
				)
	}


	@Then ('error message 2 is displayed')
	def two_error() {
		WebUI.verifyElementClickable(
				findTestObject('Object Repository/LSS/LoggedInPage/ContactInfoNoPhoneError')
				)

		WebUI.verifyElementClickable(
				findTestObject('Object Repository/LSS/LoggedInPage/ContactInfoNoEmailError')
				)


	}



	@When ('back button is clicked')
	def back_clicked() {
		WebUI.click(
				findTestObject('Object Repository/LSS/LoggedInPage/ContactInfoBackBtn')
				)
	}






	@When ('select location type "Home".')
	def select_loc_home() {
		WebUI.selectOptionByIndex(findTestObject(
				'Object Repository/LSS/LoggedInPage/LocType'
				), 1)
	}




	//	@And ('continue button is clicked')
	//	def click_cont_cont_info() {
	//		WebUI.click(
	//			findTestObject('Object Repository/LSS/LoggedInPage/ContactInfoContinueBtn')
	//)
	//	}
	//



	@And ('enter address "34405 12 Mile RD, Warren, MI 48331"')
	def strt_entered() {
		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoggedInPage/LocStreet1')
				, "34405 12 Mile RD, Warren, MI 48331")

		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoggedInPage/LocState')
				, "ABCD")


		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoggedInPage/LocZip')
				, "12345")


		WebUI.selectOptionByIndex(findTestObject(
				'Object Repository/LSS/LoggedInPage/LocStateDD'
				), 1)
	}



	@And ('Schedule Appointment page is displayed')
	def sched_app_pg_disp() {
		WebUI.delay(30)


		assert WebUI.getUrl() == 'https://selfschedule-uat.aiminspect.com/schedule'

	}



	@When ('select presence "I will not be there"')
	def i_wont_be_there_select() {
		WebUI.selectOptionByIndex(findTestObject(
				'Object Repository/LSS/LoggedInPage/InspLocOnSiteContact'
				), 1)
	}



	@And ('enter first name "Tom".')
	def enter_fn() {

		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoggedInPage/LessFirstName')
				, "Tom")

	}

	@And ('enter last name "Cruz".')
	def enter_ln() {

		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoggedInPage/LessLastName')
				, "Cruz")

	}

	@And ('enter phone number "2487765433".')
	def enter_ph() {

		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoggedInPage/LessPhone')
				, "2487765433")

	}


	@And ('enter email "Cruz@mail.com".')
	def enter_email() {

		WebUI.sendKeys(
				findTestObject('Object Repository/LSS/LoggedInPage/LessMail')
				, "Cruz@mail.com")

	}


	@And ('appointment dates are available')
	def app_sched_avail() {
		WebUI.verifyElementClickable(
				findTestObject('Object Repository/LSS/LoggedInPage/AppSchedulerCalender')
				)
	}



	@When ('select date')
	def select_date() {
		WebUI.click(
				findTestObject('Object Repository/LSS/LoggedInPage/AppSchedulerSelectDate')
				)


	}


	@And ('select time slot')
	def select_time() {
		WebUI.click(
				findTestObject('Object Repository/LSS/LoggedInPage/AppSchedulerTime')
				)
	}



	@Then ('Review Appointment page is displayed')
	def review_app_disp() {
		WebUI.delay(30)


		assert WebUI.getUrl() == 'https://selfschedule-uat.aiminspect.com/review'

	}


	@Then ("'Existing appointment' page is displayed")
	def exist_app_disp() {
		WebUI.delay(30)


		assert WebUI.getUrl() == 'https://selfschedule-uat.aiminspect.com/existing-appointment'

	}




	@And ('click Send Request button')
	def click_send_req() {

		WebUI.click(
				findTestObject('Object Repository/LSS/LoggedInPage/ContactInfoContinueBtn')
				)

	}

	@Then ('Confirmed Page is displayed')
	def conf_pg_disp() {
		WebUI.delay(30)


		assert WebUI.getUrl() == 'https://selfschedule-uat.aiminspect.com/confirmation'
	}







}