<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Enter_Valid_Acc_ErrorMessage</name>
   <tag></tag>
   <elementGuidId>34b7fd3a-ac25-4696-b99c-303f71afadcb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;log-in&quot;]/form/div/div/div[1]/span</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'error-message']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>error-message</value>
   </webElementProperties>
</WebElementEntity>
