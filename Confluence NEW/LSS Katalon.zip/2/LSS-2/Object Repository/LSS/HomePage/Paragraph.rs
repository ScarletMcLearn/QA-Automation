<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Paragraph</name>
   <tag></tag>
   <elementGuidId>3c510afc-bf89-4ad9-9c15-3f3d3363fbd7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;welcome&quot;]/div/div/div</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'col-sm-10']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-sm-10</value>
   </webElementProperties>
</WebElementEntity>
