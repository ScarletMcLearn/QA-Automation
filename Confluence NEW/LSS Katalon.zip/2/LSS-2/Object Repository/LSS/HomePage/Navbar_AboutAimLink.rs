<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Navbar_AboutAimLink</name>
   <tag></tag>
   <elementGuidId>3d4f4fa4-da8e-41e4-9bfb-c8c59645c113</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@href = 'http://homepage.aiminspections.com/about-us']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>http://homepage.aiminspections.com/about-us</value>
   </webElementProperties>
</WebElementEntity>
