<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>VehicleMainPicOverlay</name>
   <tag></tag>
   <elementGuidId>9cc8ad6b-e4f8-450f-b3a4-1d5d14fb3bbb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'ReactModal__Body--open')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ReactModal__Body--open</value>
   </webElementProperties>
</WebElementEntity>
