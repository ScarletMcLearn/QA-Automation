<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ImgZoomOut</name>
   <tag></tag>
   <elementGuidId>8ffcf3fb-6dac-47fd-b27e-165cbf01f4b7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@aria-label, 'Zoom out')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Zoom out</value>
   </webElementProperties>
</WebElementEntity>
