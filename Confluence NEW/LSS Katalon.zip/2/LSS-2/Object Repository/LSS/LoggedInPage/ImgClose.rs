<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ImgClose</name>
   <tag></tag>
   <elementGuidId>235f4ca9-9bcc-43cf-aa35-cf85e6f56b46</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@aria-label, 'Close lightbox')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Close lightbox</value>
   </webElementProperties>
</WebElementEntity>
