<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>HelloHeading</name>
   <tag></tag>
   <elementGuidId>998e511f-3235-4f29-8a4d-6a4742b8d2e0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@h1, 'Hello, ')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;condition&quot;]/div[1]/div/h1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>h1</name>
      <type>Main</type>
      <value>Hello, </value>
   </webElementProperties>
</WebElementEntity>
