<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ImgZoomIn</name>
   <tag></tag>
   <elementGuidId>34b3b3c5-21b7-4e8c-af8d-f7750a688836</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@aria-label, 'Zoom in')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Zoom in</value>
   </webElementProperties>
</WebElementEntity>
