<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>VehicleInspectionDate</name>
   <tag></tag>
   <elementGuidId>657c541e-797e-4df6-9d85-0456cd92c02c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@div, 'Inspection Date: ') and contains(@class, 'inspection-fact')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;condition&quot;]/div[3]/div/div/div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>div</name>
      <type>Main</type>
      <value>Inspection Date: </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>inspection-fact</value>
   </webElementProperties>
</WebElementEntity>
