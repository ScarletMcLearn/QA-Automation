<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>OverviewHeader</name>
   <tag></tag>
   <elementGuidId>66191192-da33-4b71-ac00-129b0eb9fb9b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@header-text, 'Overview')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;condition&quot;]/div[2]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>header-text</name>
      <type>Main</type>
      <value>Overview</value>
   </webElementProperties>
</WebElementEntity>
