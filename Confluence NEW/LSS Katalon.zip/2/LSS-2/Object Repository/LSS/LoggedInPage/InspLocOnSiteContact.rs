<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>InspLocOnSiteContact</name>
   <tag></tag>
   <elementGuidId>3a6404d3-d54d-4fd0-b66b-f76945393c8b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@name, 'lesseeIsPresent')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>lesseeIsPresent</value>
   </webElementProperties>
</WebElementEntity>
