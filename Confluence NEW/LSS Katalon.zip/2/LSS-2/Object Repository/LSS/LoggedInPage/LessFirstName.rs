<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>LessFirstName</name>
   <tag></tag>
   <elementGuidId>4c8bf92e-eb9f-4b02-8728-87909f87feb0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@name, 'onSiteContactFirstName')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>onSiteContactFirstName</value>
   </webElementProperties>
</WebElementEntity>
