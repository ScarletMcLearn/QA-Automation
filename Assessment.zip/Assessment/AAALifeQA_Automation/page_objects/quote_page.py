import pytest as pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait

from pageobjects.basepage import BasePage

from values import strings

class QuotePage(BasePage):

    def __init__(self, driver):
        self.driver = driver
  
  
    def find_element(self, element):
        element = driver.find_element_by_id(element)
        return element

    def fill_element(self, element):
        element = find_element(element)

        if element.get_attribute('id') == 'zip':
            element.send_keys(strings.zip_code)
        elif element.get_attribute('id') == 'gender':
            element.select_element_by_visible_text(strings.gender)
        elif element.get_attribute('id') == 'month':
            element.select_element_by_visible_text(strings.month)
        elif element.get_attribute('id') == 'day':
            element.select_element_by_visible_text(strings.day)
        elif element.get_attribute('id') == 'year':
            element.select_element_by_visible_text(strings.year)
        elif element.get_attribute('id') == 'isMemberYes':
            element.click()
        elif element.get_attribute('id') == 'contact_email':
            element.send_keys(strings.mail)
        elif element.get_attribute('id') == 'feet':
            element.select_element_by_visible_text(strings.feet)
        elif element.get_attribute('id') == 'inches':
            element.select_element_by_visible_text(strings.inch)
        elif element.get_attribute('id') == 'weight':
            element.send_keys(strings.weight)  
        elif element.get_attribute('id') == 'nicotineUseNo':
            element.click()
        elif element.get_attribute('id') == 'rateYourHealth':
            element.select_element_by_visible_text(strings.rate_of_health)   
        elif element.get_attribute('id') == 'coverageAmount':
            element.select_element_by_visible_text(strings.coverage_amount)    
        elif element.get_attribute('id') == 'termLength':
            element.select_element_by_visible_text(strings.term_length)  

    def submit_form(self):
        element = find_element('seeQuote')
        element.clic()

    




        # //input[@id='zip']
        # //option[contains(text(),'Male')]
        # //option[contains(text(),'May')]
        # //div[@class='date small-3 columns']//option[8]
        # //option[contains(text(),'1978')]
        # //*[@id="quoteForm"]/div/div[1]/div[3]/fieldset/div/label[1]/span
        # //input[@id='contact_email']
        # //select[@id='feet']//option[contains(text(),'5')]
        # //select[@id='inches']//option[contains(text(),'6')]
        # //input[@id='weight']
        # //*[@id="quoteForm"]/div/div[3]/div[1]/div[3]/fieldset/div/label[2]/span
        # //option[contains(text(),'Excellent')]
        # //option[contains(text(),'$2,000,000')]
        # //option[contains(text(),'15 Years')]
        # //button[@id='seeQuote']