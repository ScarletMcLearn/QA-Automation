from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

import pytest as pytest

from values import strings



class BasePage:

    @pytest.allure.step("Validate Page Title is present")
    def validate_title_is_present(self):
        title = WebDriverWait(self.driver.instance, 10).until(
            EC.visibility_of_element_located((
                By.CLASS_NAME, "site-title")))
        assert title.is_displayed()

    @pytest.allure.step("Validate Page Icon is present")
    def validate_icon_is_present(self):
        icon = WebDriverWait(self.driver.instance, 10).until(
            EC.visibility_of_element_located((
                By.CLASS_NAME, "header-logo-cta")))
        assert icon.is_displayed()

    # @pyest.allure.step("Validate Page Top Menu is present")
    # def validate_menu_options_are_present(self):
    #     top_menu = WebDriverWait(self.driver.instance, 10).until(
    #         EC.visibility_of_element_located((
    #             By.ID, "top-menu")))
    #     assert top_menu.is_displayed()t
