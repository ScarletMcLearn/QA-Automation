import unittest

from webdriver import Driver

from values import strings

from page_objects import quote_page.QuotePage


class TestAAALife(unittest.TestCase):

    def setUp(self):
        self.driver = Driver()
        self.driver.navigate(strings.base_url)

    def test_insurance_quote_input_component(self):
        quote_page = QuotePage(self.driver)
        quote_page.validate_title_is_present()
        quote_page.validate_icon_is_present()
        quote_page.validate_heading_is_present()
        quote_page.validate_zip_field_is_present()
        quote_page.validate_gender_field_is_present()
        quote_page.validate_dob_field_is_present()
        quote_page.validate_member_radio_button_is_present()
        quote_page.validate_email_field_is_present()
        quote_page.validate_gender_field_is_present()
        quote_page.validate_height_inch_field_is_present()
        quote_page.validate_height_ft_field_is_present()
        quote_page.validate_weight_field_is_present()
        quote_page.validate_bool_radio_button_is_present()
        quote_page.validate_rate_health_menu_is_present()
        quote_page.validate_coverage_amount_menu_is_present()
        quote_page.validate_term_length_menu_is_present()
        quote_page.validate_see_qoute_menu_is_present()
        home_screen.validate_social_media_links()

    def tearDown(self):
        self.driver.instance.quit()



    

if __name__ == '__main__':
    unittest.main()