'use strict';

module.exports = function (status, cb) {
	return cb();
};

