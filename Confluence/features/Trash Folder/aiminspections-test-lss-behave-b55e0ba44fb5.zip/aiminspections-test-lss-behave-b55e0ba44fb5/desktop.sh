behave -D device_type=desktop --tags=desktop $*
