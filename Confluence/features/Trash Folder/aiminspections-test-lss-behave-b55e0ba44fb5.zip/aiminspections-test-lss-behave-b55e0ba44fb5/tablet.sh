behave -D device_type=tablet --tags=tablet $*
