behave -D device_type=mobile --tags=mobile $*
