require_relative '../../support/env.rb'


# Project folder Required files to run:
# - \Cucumber\features\DC-Geopopup-Redirects\
# - \Cucumber\features\support\common\xpath\xpath.yml
# - \Cucumber\features\support\world_extensions.rb

# USE THIS IF WANT TO USE DIFFERENT XPATH FILE
#project_root = File.expand_path('../', __FILE__)
#$GEO_PATH = YAML.load_file(project_root + "/dc-geo.yml") 
