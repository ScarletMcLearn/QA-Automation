#FOR PDA

module LOGIN
  def login_pda_application(userName, password)
    visit($PDA_BASE_URL)
    fill_in('userName', :with => userName)
    fill_in('userPassword', :with => password)
    find(:xpath,"//*[@class='btn btn-primary']").click
    sleep 3
  end

  def saml_login_pda_application
    visit($PDA_BASE_URL)
    sleep 3
    # wait for the redirection to the SAML page

    fill_in('pf.username', :with => "tst_p_pdatest")
    fill_in('pf.pass', :with => "9bx43XDn")

    click_button('Login')

    sleep 3
  end
end
World(LOGIN)