
############################## Scenario 1 #######################################
Then(/^user should be able to login and see "([^"]*)" as heading$/) do |heading|
	find(:xpath,$PDA_XPATH['pda_heading']).text.should match(heading)
end

############################## Scenario 2 #######################################
Given(/^user clicks on Products link$/) do
  find(:xpath,$PDA_XPATH['products_link']).click
end

############################## Scenario 3 #######################################
Given(/^user clicks on SAP_Region link$/) do
  find(:xpath,$PDA_XPATH['sap_region_link']).click
end

############################## Scenario 4 #######################################
Given(/^user clicks on Purchase_Types link$/) do
  find(:xpath,$PDA_XPATH['purchase_type_link']).click
end

############################## Scenario 5 #######################################
Given(/^user clicks on Payment_Method link$/) do
  find(:xpath,$PDA_XPATH['payment_method_link']).click
end

############################## Scenario 6 #######################################
Given(/^user clicks on Consumer_Application link$/) do
  find(:xpath,$PDA_XPATH['consumer_application_link']).click
end

############################## Scenario 7 #######################################
Given(/^user clicks on Application_Countries link$/) do
  find(:xpath,$PDA_XPATH['application_countries_link']).click
end

############################## Scenario 8 #######################################
Given(/^user clicks on Product_Language_Packs link$/) do
  find(:xpath,$PDA_XPATH['product_lang_link']).click
end

############################## Scenario 9 #######################################
Given(/^user clicks on Application_Country_Payment link$/) do
  find(:xpath,$PDA_XPATH['application_country_payment_link']).click
end

############################## Scenario 10 #######################################
Given(/^user clicks on Product_Attributes link$/) do
  page.execute_script('window.scrollTo(0,300)')
  find(:xpath,$PDA_XPATH['product_attribute_link']).click
  sleep 5
end

And(/^selects 'Effective Immediately' option$/) do
  find(:xpath,$PDA_XPATH['effective_immediately_radioButton']).click
	sleep 2
end

############################## Scenario 11 #######################################
And(/^selects 'Effective Later' option$/) do
 find(:xpath,$PDA_XPATH['effective_later_radioButton']).click
 sleep 2
end

And(/^selects date '(\d+)' days next to today$/) do |n|
  find(:xpath,$PDA_XPATH['date_InputBox']).click()
  sleep 2
  day=Date.today+(n.to_i)
  target = Date.strptime("#{day}",'%Y-%m-%d')
  target_month_year = target.strftime('%B %Y')
  selected_month_year = (find(:xpath,'//span[@ng-bind="dateValue"]').native.text)
  unless target_month_year == selected_month_year
    find(:xpath,'//i[@ng-click="nextMonth()"]').click
    sleep 1
  end
  find(:xpath,'//span[@class="day ng-binding"]', :text =>Regexp.new("^#{day.day}$"),match: :prefer_exact).click
  sleep 2
end

############################## Scenario 12 #######################################
Given(/^user clicks on Offerings link$/) do
  find(:xpath,$PDA_XPATH['offerings_link']).click
	sleep 5
end

############################# Scenario 16 ########################################

Given(/^user clicks on Language_Packs link$/) do
  find(:xpath,$PDA_XPATH['language_pack_link']).click
	sleep 5
end

And(/^user clicks on Add Pack button$/) do
  find(:xpath,$PDA_XPATH['add_button']).click
end

And(/^user adds language tag as "([^"]*)" and language name as "([^"]*)"$/) do |lang_tag, lang_name|
  fill_in 'languageTag', :with => lang_tag
  fill_in 'languageName', :with => lang_name
  find(:xpath,$PDA_XPATH['save_button']).click
end

Then(/^language added message "([^"]*)" is displayed on screen$/) do |lang_add|
  find(:xpath,$PDA_XPATH['lang_info']).text.should match(lang_add)
  sleep 5
end

And(/^search for language tag added "([^"]*)"$/) do |lang_tag|
  fill_in 'search', :with => lang_tag
end

And(/^delete the added language$/) do
  find(:xpath,$PDA_XPATH['delete_button']).click
  Capybara.page.driver.browser.switch_to.alert.accept
end

Then(/^language delete message is dispalyed "([^"]*)"$/) do |lang_delete|
  find(:xpath,$PDA_XPATH['lang_info']).text.should match(lang_delete)
end

############################# Scenario 17 ########################################

Then(/^error message is displayed "([^"]*)"$/) do |error_message|
    find(:xpath,$PDA_XPATH['error_msg']).text.should match (error_message)
end

############################# Scenario 18 ########################################

Then(/^file doesn't get upload and displays upload message as "([^"]*)"$/) do |upload_message|
    find(:xpath,$PDA_XPATH['upload_msg']).text.should have_content (upload_message)
end

############################# Scenario 19 ########################################

Then(/^validate the dates displayed are in ascending order$/) do
    dates_list = find(:xpath, $PDA_XPATH['offerings_dates']).all('li')
    sort_dates_list = dates_list.sort
    sort_dates_list.should == dates_list
end

############################## Scenario 20 #######################################
Given(/^user clicks on Promotions link$/) do
  find(:xpath,$PDA_XPATH['promotions']).click
end
