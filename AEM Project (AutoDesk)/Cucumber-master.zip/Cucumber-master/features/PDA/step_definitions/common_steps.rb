
# Common Steps across your project's feature files

############################# COMMON loading pages #############################

Given(/^user login to PDA application with "([^"]*)" and "([^"]*)"$/) do |username, password|
  login_pda_application(username, password)
end

Given(/^user SAML logins to PDA application with a test service account$/) do
  saml_login_pda_application
end

Given(/^user has already logged in to PDA application in the previous scenario$/) do
  # do nothing here
  visit($PDA_BASE_URL)
  sleep 3
end

When(/^user uploads the file "([^"]*)"$/) do |file_path|
  ## Cheking is it remote request
  if !ENV['SAUCE_ENV'].to_s.empty?
    ## Allows remote uploads.
    Capybara.page.driver.browser.file_detector = lambda {|args| args.first.to_s if File.exists?(args.first.to_s)}
  end
  page.attach_file('dropzone', File.expand_path(file_path), visible: false)
  sleep 20
end

Then(/^upload summary "([^"]*)" is displayed on screen$/) do |upload_summary|
  find(:xpath,$PDA_XPATH['upload_summary_box']).should have_content(upload_summary)
end

Then(/^upload summary "([^"]*)", "([^"]*)", "([^"]*)" is displayed on screen$/) do |rows_present, rows_inserted, rows_error|
  find(:xpath,$PDA_XPATH['inserted_summary']).should have_content(rows_inserted)
  find(:xpath,$PDA_XPATH['error_summary']).should have_content(rows_error)
  find(:xpath,$PDA_XPATH['rows_summary']).should have_content(rows_present)
end

Then(/^upload summary given "([^"]*)", "([^"]*)", "([^"]*)" is displayed on screen$/) do |rows_present, rows_inserted_in_holding, rows_error|
  find(:xpath,$PDA_XPATH['offering_inserted_summary']).should have_content(rows_inserted_in_holding)
  find(:xpath,$PDA_XPATH['error_summary']).should have_content(rows_error)
  find(:xpath,$PDA_XPATH['rows_summary']).should have_content(rows_present)
end

Then(/^upload summary "([^"]*)", "([^"]*)", "([^"]*)", "([^"]*)" is displayed on screen$/) do |rows_present, rows_inserted, rows_error, rows_update|
  find(:xpath,$PDA_XPATH['inserted_summary']).should have_content(rows_inserted)
  find(:xpath,$PDA_XPATH['error_summary']).should have_content(rows_error)
  find(:xpath,$PDA_XPATH['rows_summary']).should have_content(rows_present)
  find(:xpath,$PDA_XPATH['update_summary']).should have_content(rows_update)
end

Then(/^upload summary "([^"]*)", "([^"]*)", "([^"]*)", "([^"]*)", "([^"]*)" is displayed on screen$/) do |rows_present, rows_inserted, rows_error, rows_update, rows_removed|
  find(:xpath,$PDA_XPATH['inserted_summary']).should have_content(rows_inserted)
  find(:xpath,$PDA_XPATH['error_summary']).should have_content(rows_error)
  find(:xpath,$PDA_XPATH['rows_summary']).should have_content(rows_present)
  find(:xpath,$PDA_XPATH['update_summary']).should have_content(rows_update)
  find(:xpath,$PDA_XPATH['remove_summary']).should have_content(rows_removed)
end

Then(/^(do|do_not) this: error summary "([^"]*)" is displayed on screen$/) do |do_or_do_not, error_summary|
  find(:xpath,$PDA_XPATH['error_summary_box']).should have_content(error_summary) if(do_or_do_not)=='do'
end

And(/^waits to upload the file$/) do
  sleep 40
end

And(/^user logs out of PDA site$/) do
  find(:xpath,$PDA_XPATH['logout']).click
  #expire_cookies
  sleep 5
end


=begin Not required for download functionality
And(/^user navigates to url "([^"]*)"$/) do |url|
  visit(url)
  sleep 5
end

Given(/^user clicks on Export Data$/) do
  find(:xpath,$PDA_XPATH['export_link']).click
  sleep 10
end
=end
