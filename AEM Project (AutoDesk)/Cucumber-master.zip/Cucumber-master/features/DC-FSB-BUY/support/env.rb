require_relative '../../support/env.rb'

#project_root = File.expand_path('../../..', __FILE__)
#$PATH = YAML.load_file(project_root + "/DC-FSB-BUY/support/xpath.yml")
#$SEO = YAML.load_file(project_root + "/DC-FSB-BUY/support/seo.yml")
